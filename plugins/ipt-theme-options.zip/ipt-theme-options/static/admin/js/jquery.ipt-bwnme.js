/**
 *  Custom plugin to be fired on nav-menus.php
 *
 *  It applies the fontIconPicker on existing and newly added elements
 *  Makes use of
 *  jQuery Boilerplate - v3.3.2
 *  A jump-start for jQuery plugins development.
 *  http://jqueryboilerplate.com
 *
 *  Made by Zeno Rocha
 *  Under MIT License
 */
;(function ( $, window, document, undefined ) {

	// Create the defaults once
	var pluginName = "iptBootstrapWalkerNavMenuEdit",
	defaults = {
		iconSource: {"Web Applications":[58892,61442,61451,61454,61456,61465,61474,61486,61498,61579,61584,61587,61591,61598,61612,61642,61643,61672,61677,61678,61709,61710,61714,61729,61730,61734,61763,61831,57440,57442,57467,57486,57487,57488,57489,57497,57512,57513,57543,57544,57549,57367,57368,57557,57558,57559,57560,57561,57562,57563,57564,57567,57571,57572,57424,57678,57388,57389,57735,57739,57740,57741,57746,57749,57750,57765],"Business Icons":[61447,61468,61485,61557,61570,61574,61632,61669,61670,57427,57428,57443,57444,57445,57461,57464,57465,57360,57498,57499,57500,57501,57361,57502,57503,57504,57505,57555,57720,57731,57733],"Medical Icons":[61681,61688,61689,61690,61693,61843,57527,61680,61687],"eCommerce Icons":[61483,61484,61562,61597,57452,57453,57457,57354,57459,57460,57724],"Currency Icons":[61654,61779,61780,61781,61782,61783,61784,61785,61786,61845,57458],"Form Control Icons":[61452,61453,61460,61473,61510,61527,61528,61532,61533,61636,61637,61639,61674,61713,61726,61770,57441,57352,57353,57446,57447,57448,57359,57625,57626,57649,57650,57651,57723,57732,57744,57745],"User Action & Text Editor":[61449,61450,61470,61489,61490,61491,61492,61493,61494,61495,61496,61497,61499,61500,61506,61507,61508,61541,61582,61633,61638,61644,61645,61646,61659,61660,61661,61662,61666,61728,61733,61735,61739,61740,61757,61772,61789,61790,61792,61793,61794,61795,57490,57491,57492,57493,57494,57495,57506,57514,57515,57363,57516,57517,57565,57371,57372,57681,57682,57683,57684,57685,57686,57687,57688,57689,57377,57423,57690,57691,57373,57734,57747,57748,57751,57752,57753,57369,57754,57755,57756,57757,57758,57759,57760,57761],"Icon Spinners":[61712,57507,57362,57508,57509,57510,57511,57730],"Charts and Codes":[61481,61482,61568,61641,61742,57454,57455,57529,57530,57365,57737],"Attentive Icons":[61525,61526,61529,61530,61531,61534,61543,61544,61545,61546,61553,61614,61652,61653,61694,61736,61737,61738,61760,61766,61767,61846,57569,57614,57615,57616,57617,57618,57619,57620,57622,57623,57370,57624],"Multimedia Icons":[61441,61448,61469,61478,61479,61480,61501,61502,61515,61516,61518,61520,61521,61540,61764,61802,57346,57348,57496,57364,57573,57574,57575,57627,57628,57629,57631,57632,57633,57634,57636,57637,57638,57639,57640,57642,57643,57644,57645,57646,57647,57648,57652,57416,57417,57719,57729],"Location and Contact":[61443,61461,61476,61505,61589,61592,61664,61707,61725,61732,61745,57344,57425,57426,57462,57463,57466,57468,57469,57471,57472,57484,57550,57566,57375,57376,57726,57762,57764],"Date and Time":[61463,61555,61747,57473,57474,57475,57476,57477,57479,57480,57481],"Device Icons":[61457,61458,61477,61487,61488,61571,61600,61704,61705,61706,61723,61724,61744,57347,57349,57482,57483,57355,57356,57553,57418,57725,57727],"Tools Icons":[58923,61459,61475,61504,61558,61572,61573,61596,61601,61613,61616,61648,61668,61717,61741,61758,61771,61774,57345,57429,57430,57431,57433,57421,57439,57470,57518,57519,57520,57521,57522,57523,57420,57524,57525,57526,57366,57538,57539,57542,57554,57679,57680,57415,57736,57738],"Social Networking":[61509,61569,61580,61586,61593,61594,61595,61650,61651,61665,61715,61773,61798,61799,61804,61805,61806,61811,61812,61828,61844,57449,57374,57379,57380,57381,57382,57383,57384,57385,57386,57387,57390,57391,57392,57422,57692,57394,57693,57696,57697,57698,57699,57700,57396,57701,57702,57703,57704,57399,57705,57706,57402,57708,57403,57404,57405,57406,57407,57712,57763,57766,57767,57768,57769,57770,57771,57773,57774,57775,57780,57782,57783,57784,57785,57786],"Brands Icons":[61676,61750,61755,61756,61800,61801,61803,61808,61809,61810,61817,61818,61819,61820,61821,61822,61824,61825,61833,61834,61835,61836,61837,57393,57395,57694,57695,57397,57398,57707,57400,57401,57408,57709,57409,57710,57410,57711,57413,57718,57772,57776,57777,57778,57779,57781,57789,57790,57791,57792,57793,57794],"Files & Documents":[61462,61563,61564,61603,61686,61716,61787,61788,57350,57351,57450,57451,57357,57358,57485,57713,57714,57715,57411,57412,57716,57717,57721,57722,57728,57787,57788],"Food and Beverage":[61440,61684,61685,61692,57533,57534,57535],"Travel and Living":[61464,61547,61554,61585,61617,61649,61691,61765,57456,57531,57532,57537,57545,57546,57547,57548],"Weather & Nature Icons":[58880,58881,58882,58883,58884,58885,58886,58887,58888,58889,58890,58891,58893,58894,58895,58896,58897,58898,58899,58900,58901,58902,58903,58904,58905,58906,58907,58908,58909,58910,58911,58912,58913,58914,58915,58916,58917,58918,58919,58920,58921,58922,58925,58926,61548,61549,61634,61748,61829,61830,57536,57540,57552,57556],"Like & Dislike Icons":[61444,61445,61446,61550,61552,61561,61575,61576,61577,61578,61581,61731,61796,61797,57568,57570,57576,57577,57578,57579,57580,57581,57582,57583],"Emoticons":[61720,61721,61722,57584,57585,57586,57587,57588,57589,57590,57591,57592,57593,57594,57595,57596,57597,57598,57599,57600,57601,57602,57603,57604,57605,57606,57607,57608,57609],"Directional Icons":[61466,61467,61511,61512,61513,61514,61522,61523,61524,61536,61537,61538,61539,61559,61560,61565,61566,61604,61605,61606,61607,61608,61609,61610,61611,61618,61655,61656,61657,61658,61696,61697,61698,61699,61700,61701,61702,61703,61751,61752,61753,61754,61768,61769,61776,61777,61778,61813,61814,61815,61816,61838,61840,61841,57610,57611,57612,57613,57630,57635,57641,57653,57654,57655,57656,57657,57658,57659,57660,57661,57662,57663,57664,57665,57666,57667,57668,57669,57670,57671,57672,57673,57674,57675,57676,57677],"Other Icons":[58924,61517,61542,61556,61588,61590,61602,61635,61640,61667,61671,61673,61675,61682,61683,61708,61746,61749,61761,61762,61826,61827,61832,61842,57432,57434,57435,57436,57437,57438,57478,57528,57541,57551,57419,57621,57378,57414,57742,57743]},
		iconSearchSource: {"Web Applications":["Lines","Search","Th list","Search plus","Search minus","Download","List alt","Bookmark","List","Sign out","Sign in","Upload","Bookmark o","Rss","Globe","List ul","List ol","Sitemap","Cloud download","Cloud upload","Quote left","Quote right","Mail reply","Code","Reply all","Code fork","Rss square","Archive","Connection","Feed","Pushpin","Box add","Box remove","Download 2","Upload 2","Reply","Binoculars","Search 2","Remove","Remove 2","Accessibility","List 2","Menu","Cloud download 2","Cloud upload 2","Download 3","Upload 3","Download 4","Upload 4","Globe 2","Earth","Attachment","Bookmark 2","Bookmarks","Checkbox unchecked","Checkbox partial","Feed 2","Feed 3","Settings","List 3","Numbered list","Menu 2","Checkbox checked","Code 2","Embed","Feed 4"],"Business Icons":["User","Inbox","Book","Comment","Facebook square","Comments","Group","Comment o","Comments o","Office","Newspaper","Book 2","Books","Library","Support","Address book","Notebook","Bubbles","Bubbles 2","Bubble","Bubbles 3","Bubbles 4","Users","User 2","Users 2","User 3","User 4","Signup","Profile","Bubble 2","User 5"],"Medical Icons":["Stethoscope","Hospital o","Ambulance","Medkit","H square","Wheelchair","Aid","User md","Building o"],"eCommerce Icons":["Tag","Tags","Shopping cart","Credit card","Tag 2","Tags 2","Cart","Cart 2","Credit","Calculate","Cart 3"],"Currency Icons":["Money","Euro","Gbp","Dollar","Rupee","Cny","Ruble","Won","Bitcoin","Turkish lira","Coin"],"Form Control Icons":["Check","Times","Trash o","Refresh","Check square o","Times circle","Check circle","Times circle o","Check circle o","Cut","Copy","Save","Paste","Circle","Flag checkered","Check square","Podcast","Copy 2","Copy 3","Paste 2","Paste 3","Paste 4","Storage","Enter","Exit","Loop","Loop 2","Loop 3","Copy 4","Disk","Radio checked","Radio unchecked"],"User Action & Text Editor":["Th large","Th","Rotate right","Font","Bold","Italic","Text height","Text width","Align left","Align center","Align right","Align justify","Dedent","Indent","Adjust","Tint","Edit","Expand","External link","Chain","Paperclip","Strikethrough","Underline","Table","Columns","Unsorted","Sort down","Sort up","Rotate left","Terminal","Crop","Unlink","Superscript","Subscript","Anchor","External link square","Sort alpha asc","Sort alpha desc","Sort amount asc","Sort amount desc","Sort numeric asc","Sort numeric desc","Undo","Redo","Flip","Flip 2","Undo 2","Redo 2","Quotes left","Zoomin","Zoomout","Contract","Expand 2","Contract 2","Link","Crop 2","Scissors","Font 2","Text height 2","Text width 2","Bold 2","Underline 2","Italic 2","Strikethrough 2","Omega","Sigma","Table 2","Pilcrow","Lefttoright","Righttoleft","Console","Expand 3","Table 3","Insert template","Newtab","Indent decrease","Indent increase","Spell check","Paragraph justify","Paragraph right","Paragraph center","Paragraph left","Paragraph justify 2","Paragraph right 2","Paragraph center 2","Paragraph left 2"],"Icon Spinners":["Spinner","Busy","Spinner 2","Spinner 3","Spinner 4","Spinner 5","Spinner 6","Spinner 7"],"Charts and Codes":["Qrcode","Barcode","Bar chart o","Bars","Puzzle piece","Barcode 2","Qrcode 2","Pie","Stats","Bars 2","Bars 3"],"Attentive Icons":["Plus circle","Minus circle","Question circle","Info circle","Crosshairs","Ban","Plus","Minus","Asterisk","Exclamation circle","Warning","Tasks","Google plus square","Google plus","Plus square","Question","Info","Exclamation","Bullseye","Minus square","Minus square o","Plus square o","Eye blocked","Warning 2","Notification","Question 2","Info 2","Info 3","Blocked","Cancel circle","Spam","Close","Minus 2","Plus 2"],"Multimedia Icons":["Music","Film","Play circle o","Volume off","Volume down","Volume up","Video camera","Picture o","Play","Pause","Forward","Fast forward","Step forward","Mail forward","Play circle","Youtube play","Image","Play 2","Forward 2","Equalizer","Brightness medium","Brightness contrast","Contrast","Play 3","Pause 2","Stop 2","Forward 3","Play 4","Pause 3","Stop 3","Forward 4","First","Last","Previous","Next","Volume high","Volume medium","Volume low","Volume mute","Volume mute 2","Volume increase","Volume decrease","Shuffle","Image 2","Images","Film 2","Music 2"],"Location and Contact":["Envelope o","Home","Flag","Map marker","Phone","Phone square","Envelope","Mobile phone","Flag o","Location arrow","Microphone slash","Home 2","Home 3","Home 4","Phone 2","Phone hang up","Envelop","Location","Location 2","Map","Map 2","Mobile","Target","Flag 2","Mail","Mail 2","Mobile 2","Mail 3","Mail 4"],"Date and Time":["Clock o","Calendar","Calendar o","History","Clock","Clock 2","Alarm","Alarm 2","Stopwatch","Calendar 2","Calendar 3"],"Device Icons":["Power off","Signal","Headphones","Print","Camera","Camera retro","Hdd o","Desktop","Laptop","Tablet","Gamepad","Keyboard o","Microphone","Headphones 2","Camera 2","Print 2","Keyboard","Laptop 2","Tv","Switch","Camera 3","Screen","Tablet 2"],"Tools Icons":["Compass","Gear","Lock","Pencil","Magnet","Key","Gears","Unlock","Bullhorn","Wrench","Filter","Magic","Dashboard","Folder open o","Eraser","Unlock alt","Pencil square","Compass 2","Pencil 2","Quill","Pen","Blog","Paint format","Dice","Bullhorn 2","Compass 3","Key 2","Key 3","Lock 2","Lock 3","Unlocked","Wrench 2","Cogs","Cog","Hammer","Wand","Meter 2","Dashboard 2","Hammer 2","Magnet 2","Powercord","Filter 2","Filter 3","Pencil 3","Cog 2","Meter"],"Social Networking":["Share square o","Twitter square","Linkedin square","Github square","Twitter","Facebook","Github","Pinterest","Pinterest square","Linkedin","Github alt","Share square","Youtube square","Youtube","Stack overflow","Instagram","Flickr","Tumblr","Tumblr square","Gittip","Vimeo square","Stack","Share","Googleplus","Googleplus 2","Googleplus 3","Google drive","Facebook 2","Facebook 3","Instagram 2","Twitter 2","Twitter 3","Youtube 2","Vimeo","Vimeo 2","Flickr 2","Flickr 3","Flickr 4","Picassa","Forrst","Forrst 2","Deviantart","Deviantart 2","Steam","Github 2","Github 3","Github 4","Github 5","Blogger","Tumblr 2","Tumblr 3","Yahoo","Soundcloud","Soundcloud 2","Reddit","Lastfm","Stumbleupon","Stackoverflow","Pinterest 2","Yelp","Twitter 4","Youtube 3","Vimeo 22","Flickr 5","Facebook 4","Googleplus 4","Picassa 2","Github 6","Steam 2","Blogger 2","Linkedin 2","Flattr","Pinterest 3","Stumbleupon 2","Delicious","Lastfm 2"],"Brands Icons":["Exchange","Maxcdn","Html 5","Css 3","Xing","Xing square","Dropbox","Adn","Bitbucket","Bitbucket square","Apple","Windows","Android","Linux","Dribbble","Skype","Foursquare","Trello","Vk","Weibo","Renren","Pagelines","Stack exchange","Lanyrd","Dribbble 2","Dribbble 3","Dribbble 4","Wordpress","Joomla","Tux","Finder","Windows 2","Xing 2","Xing 3","Foursquare 2","Foursquare 3","Paypal","Paypal 2","Html 52","Css 32","Wordpress 2","Apple 2","Android 2","Windows 8","Skype 2","Paypal 3","Html 53","Chrome","Firefox","IE","Safari","Opera"],"Files & Documents":["File o","Folder","Folder open","Certificate","File text o","Folder o","File","File text","File 2","File 3","Folder 2","Folder open 2","Drawer","Drawer 2","Drawer 3","Libreoffice","File pdf","File openoffice","File zip","File powerpoint","File xml","File css","File 4","File 5","Cabinet","File word","File excel"],"Food and Beverage":["Glass","Coffee","Cutlery","Beer","Glass 2","Mug","Food"],"Travel and Living":["Road","Gift","Plane","Trophy","Briefcase","Truck","Fighter jet","Ticket","Ticket 2","Gift 2","Trophy 2","Rocket 2","Briefcase 2","Airplane","Truck 2","Road 2"],"Weather & Nature Icons":["Sunrise","Sun","Moon","Sun 2","Windy","Wind","Snowflake","Cloudy","Cloud","Weather","Weather 2","Weather 3","Cloud 2","Lightning","Lightning 2","Rainy","Rainy 2","Windy 2","Windy 3","Snowy","Snowy 2","Snowy 3","Weather 4","Cloudy 2","Cloud 3","Lightning 3","Sun 3","Moon 2","Cloudy 3","Cloud 4","Cloud 5","Lightning 4","Rainy 3","Rainy 4","Windy 4","Windy 5","Snowy 4","Snowy 5","Weather 5","Cloudy 4","Lightning 5","Thermometer","Celsius","Fahrenheit","Leaf","Fire","Cloud 6","Fire extinguisher","Sun o","Moon o","Leaf 2","Fire 2","Lightning 6","Cloud 7"],"Like & Dislike Icons":["Heart","Star","Star o","Eye","Eye slash","Retweet","Thumbs o up","Thumbs o down","Star half","Heart o","Thumb tack","Star half empty","Thumbs up","Thumbs down","Eye 2","Eye 3","Star 2","Star 3","Star 4","Heart 2","Heart 3","Heart broken","Thumbs up 2","Thumbs up 3"],"Emoticons":["Smile o","Frown o","Meh o","Happy","Happy 2","Smiley","Smiley 2","Tongue","Tongue 2","Sad","Sad 2","Wink","Wink 2","Grin","Grin 2","Cool","Cool 2","Angry","Angry 2","Evil","Evil 2","Shocked","Shocked 2","Confused","Confused 2","Neutral","Neutral 2","Wondering","Wondering 2"],"Directional Icons":["Arrow circle o down","Arrow circle o up","Arrows","Step backward","Fast backward","Backward","Eject","Chevron left","Chevron right","Arrow left","Arrow right","Arrow up","Arrow down","Chevron up","Chevron down","Arrows v","Arrows h","Hand o right","Hand o left","Hand o up","Hand o down","Arrow circle left","Arrow circle right","Arrow circle up","Arrow circle down","Arrows alt","Caret down","Caret up","Caret left","Caret right","Angle double left","Angle double right","Angle double up","Angle double down","Angle left","Angle right","Angle up","Angle down","Chevron circle left","Chevron circle right","Chevron circle up","Chevron circle down","Level up","Level down","Toggle down","Toggle up","Toggle right","Long arrow down","Long arrow up","Long arrow left","Long arrow right","Arrow circle o right","Arrow circle o left","Toggle left","Point up","Point right","Point down","Point left","Backward 2","Backward 3","Eject 2","Arrow up left","Arrow up 2","Arrow up right","Arrow right 2","Arrow down right","Arrow down 2","Arrow down left","Arrow left 2","Arrow up left 2","Arrow up 3","Arrow up right 2","Arrow right 3","Arrow down right 2","Arrow down 3","Arrow down left 2","Arrow left 3","Arrow up left 3","Arrow up 4","Arrow up right 3","Arrow right 4","Arrow down right 3","Arrow down 4","Arrow down left 3","Arrow left 4","Tab"],"Other Icons":["None","Stop","Compress","Random","Lemon o","Square o","Bell","Flask","Square","Legal","Flash","Umbrella","Lightbulb o","Suitcase","Bell o","Circle o","Shield","Rocket","Ellipsis h","Ellipsis v","Female","Male","Bug","Dot circle o","Droplet","Pacman","Spades","Clubs","Diamonds","Pawn","Bell 2","Bug 2","Lab","Shield 2","Tree","Checkmark circle","Google","IcoMoon","Checkmark","Checkmark 2"]}
	};

	// The actual plugin constructor
	function Plugin ( element, options ) {
		this.element = $(element);
		this.settings = $.extend( {}, defaults, options );
		this._defaults = defaults;
		this._name = pluginName;
		this.init();
	}

	Plugin.prototype = {
		init: function () {
			// Add fip to existing text boxes
			this.initFIP();
			// Attach to the addables
			this.attachSortableListEvent();
		},
		initFIP: function() {
			this.applyFIP();
		},
		attachSortableListEvent: function () {
			// We listen to all AJAX events
			// That is the only way since no event is fired upon addition of DOM
			// Or not that I know of (yet)
			$(document).ajaxSuccess( $.proxy( function(e, jqXHR, ajaxOp, data) {
				if ( ajaxOp.data.indexOf( 'add-menu-item' ) !== -1 ) {
					this.applyFIP();
				}
			}, this) );
		},
		applyFIP: function() {
			this.element.find('.ipt-navmenu-iconpicker').fontIconPicker({
				source: this.settings.iconSource,
				searchSource: this.settings.iconSearchSource,
				useAttribute: true,
				attributeName: 'data-ipt-icomoon',
				theme: 'fip-ipt',
				appendTo: 'body',
				emptyIconValue: 'none',
				autoClose: false // Save FIP from event propagation
			});
		}
	};

	var methods = {
		init: function( options ) {
			this.each(function() {
				if ( !$.data( this, "plugin_" + pluginName ) ) {
					$.data( this, "plugin_" + pluginName, new Plugin( this, options ) );
				}
			});
		}
	};

	// A really lightweight plugin wrapper around the constructor,
	// preventing against multiple instantiations
	$.fn[ pluginName ] = function ( method ) {
		if( methods[method] ) {
			return methods[method].apply( this, Array.prototype.slice.call( arguments, 1 ) );
		} else if ( typeof( method ) == 'object' || !method ) {
			return methods.init.apply(this, arguments);
		} else {
			$.error( 'Method ' + method + ' does not exist on jQuery.' + pluginName );
			return this;
		}

		// chain jQuery functions
		return this;
	};

})( jQuery, window, document );

jQuery(document).ready(function($) {
	$('body').iptBootstrapWalkerNavMenuEdit();
});
