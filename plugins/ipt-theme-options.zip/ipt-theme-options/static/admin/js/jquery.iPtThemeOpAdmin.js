/*
 *  jQuery Boilerplate - v3.3.2
 *  A jump-start for jQuery plugins development.
 *  http://jqueryboilerplate.com
 *
 *  Made by Zeno Rocha
 *  Under MIT License
 */
// the semi-colon before function invocation is a safety net against concatenated
// scripts and/or other plugins which may not be closed properly.
;(function ( $, window, document, undefined ) {

	// undefined is used here as the undefined global variable in ECMAScript 3 is
	// mutable (ie. it can be changed by someone else). undefined isn't really being
	// passed in so we can ensure the value of it is truly undefined. In ES5, undefined
	// can no longer be modified.

	// window and document are passed through as local variable rather than global
	// as this (slightly) quickens the resolution process and can be more efficiently
	// minified (especially when both are regularly referenced in your plugin).

	// Create the defaults once
	var pluginName = 'iPtThemeOpAdmin',
	defaults = {
		ajaxLoaderID: 'ipt_theme_op_settings_ajax_loader',
		forceAjaxSubmit: false,
		sendAsStr: true
	};

	// The actual plugin constructor
	function Plugin ( element, options ) {
		this.element = $( element );
		// jQuery has an extend method which merges the contents of two or
		// more objects, storing the result in the first object. The first object
		// is generally empty as we don't want to alter the default options for
		// future instances of the plugin
		this.settings = $.extend( {}, defaults, options );
		this._defaults = defaults;
		this._name = pluginName;
		this.init();
	}

	Plugin.prototype = {
		init: function () {
			// Add support for inline options
			for ( var optionID in this.settings ) {
				if ( this.element.data( optionID ) !== undefined && this.element.data( optionID ) !== null ) {
					this.settings[optionID] = this.element.data( optionID );
				}
			}

			// Init the forms
			this.initFormAJAX();

		},
		initFormAJAX: function () {
			this.element.find('form').each( $.proxy( function(i, elm) {
				// Attach the ajax event if either force ajax is set to true or
				// the form has data-ajax-submit set to true
				if ( this.settings.forceAjaxSubmit == true || $(elm).data('ajaxSubmit') ) {
					this.attachFormAjaxEvent( $( elm ) );
				}
			}, this ) );
		},
		attachFormAjaxEvent: function( form ) {
			form.on( 'submit', $.proxy( function( event ) {
				// Prevent the submit
				event.preventDefault();

				// Init the variables
				var ajaxLoader, data;
				ajaxLoader = $( '#' + this.settings.ajaxLoaderID ),
				ajaxLoaderAnimator = ajaxLoader.find('.ipt_uif_ajax_loader_inner'),
				ajaxLoaderText = ajaxLoader.find('.ipt_uif_ajax_loader_text');
				ajaxLoaderText.html( ajaxLoader.data( 'wait' ) );

				if ( this.settings.sendAsStr ) {
					data = {
						action: form.find('[name="action"]').val(),
						post: form.serialize(),
						send_as_str: true,
						look_into: 'post'
					};
				} else {
					data = form.serialize();
				}

				ajaxLoaderAnimator.addClass('ipt_uif_ajax_loader_animate');
				ajaxLoader.show();

				$.ajax({
					url: form.attr( 'action' ),
					type: form.attr( 'method' ),
					dataType: 'json',
					data: data
				})
				.done(function( response, textStatus, jqXHR ) {
					if ( response !== null && response.success == true ) {
						ajaxLoaderText.html( ajaxLoader.data( 'done' ) );
					} else {
						ajaxLoaderText.html( ajaxLoader.data( 'error' ) + ' ' + response.errors.join( ' :: ' ) );
					}

				})
				.fail(function( jqXHR, textStatus, errorThrown ) {
					ajaxLoaderText.html( ajaxLoader.data( 'error' ) + ' ' + textStatus + ' :: ' + errorThrown );
				})
				.always(function() {
					ajaxLoaderAnimator.removeClass('ipt_uif_ajax_loader_animate');
					setTimeout( function() {
						ajaxLoader.fadeOut( 'fast' );
					}, 1000 );
				});

			}, this ) );
		}
	};

	var methods = {
		init: function( options ) {
			this.each(function() {
				if ( !$.data( this, "plugin_" + pluginName ) ) {
					$.data( this, "plugin_" + pluginName, new Plugin( this, options ) );
				}
			});
		}
	};

	// A really lightweight plugin wrapper around the constructor,
	// preventing against multiple instantiations
	$.fn[ pluginName ] = function ( method ) {
		if( methods[method] ) {
			return methods[method].apply( this, Array.prototype.slice.call( arguments, 1 ) );
		} else if ( typeof( method ) == 'object' || !method ) {
			return methods.init.apply(this, arguments);
		} else {
			$.error( 'Method ' + method + ' does not exist on jQuery.' + pluginName );
			return this;
		}

		// chain jQuery functions
		return this;
	};

})( jQuery, window, document );

jQuery(document).ready(function($) {
	$('.ipt_uif').iPtThemeOpAdmin();
});
