<?php
/**
 * Set of navigation APIs
 *
 * Used mainly by the frontend
 *
 * @package iPanelThemes Theme Options
 * @subpackage APIs
 */

function ipt_theme_op_navigation_logged_in_nav( $echo = true ) {
	global $ipt_theme_op_settings;
	$return = '';
	$op = $ipt_theme_op_settings['navigation'];
	if ( ! isset( $op['logged_in_links'] ) || empty ( $op['logged_in_links'] ) ) {
		return $return;
	}
	foreach ( $op['logged_in_links'] as $link ) {
		// Start the list
		$return .= '<li><a href="' . esc_url( $link['link'] ) . '">';
		// Add the icon
		$return .=  ( $link['icon'] != '' && $link['icon'] != 'none' ? '<i class="ipticm" data-ipt-icomoon="&#x' . dechex( $link['icon'] ) . ';"></i> ' : '' );
		// Close the list
		$return .= $link['title'] . '</a></li>';
	}
	if ( $echo ) {
		echo $return;
	}
	return $return;
}

function ipt_theme_op_navigation_logged_out_nav( $echo = true ) {
	global $ipt_theme_op_settings;
	$return = '';
	$op = $ipt_theme_op_settings['navigation'];
	if ( ! isset( $op['logged_out_links'] ) || empty ( $op['logged_out_links'] ) ) {
		return $return;
	}
	foreach ( $op['logged_out_links'] as $link ) {
		// Start the list
		$return .= '<li><a href="' . esc_url( $link['link'] ) . '">';
		// Add the icon
		$return .=  ( $link['icon'] != '' && $link['icon'] != 'none' ? '<i class="ipticm" data-ipt-icomoon="&#x' . dechex( $link['icon'] ) . ';"></i> ' : '' );
		// Close the list
		$return .= $link['title'] . '</a></li>';
	}
	if ( $echo ) {
		echo $return;
	}
	return $return;
}

function ipt_theme_op_navigation_brand( $echo = true ) {
	global $ipt_theme_op_settings;
	$return = '';
	$op = $ipt_theme_op_settings['navigation'];
	if ( ! isset( $op['brand'] ) ) {
		$op['brand'] = '';
	}
	if ( ! isset( $op['image'] ) ) {
		$op['image'] = '';
	}
	if ( $op['image'] != '' ) {
		$return .= '<img src="' . $op['image'] . '" alt="" /> ';
	}
	$return .= $op['brand'];
	if ( $echo ) {
		echo $return;
	}
	return $return;
}
