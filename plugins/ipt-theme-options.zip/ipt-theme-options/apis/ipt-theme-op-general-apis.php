<?php
/**
 * Set of general APIs
 *
 * Used both by frontend and back end
 *
 * @package iPanelThemes Theme Options
 * @subpackage APIs
 */

/**
 * Get the default theme settings
 *
 * This is updated on plugin updates automatically
 *
 * Also themes can modify it by using the filter
 *
 * @uses filter  ipt_theme_op_default_settings
 * @return array The default settings array
 */
function ipt_theme_op_get_default_settings() {
	return apply_filters( 'ipt_theme_op_default_settings', get_option( 'ipt_theme_op_settings_default', false ) );
}

/**
 * Save the new settings
 *
 * It automatically sanitizes the new settings at per with the default one
 * Also repopulates the global array
 * @param  array $new_settings The new settings array. You can pass direct $_POST variable
 * @return void
 */
function ipt_theme_op_set_settings( $new_settings ) {
	$sanitize_settings = ipt_theme_op_merge_arrays( $new_settings, ipt_theme_op_get_default_settings() );
	update_option( 'ipt_theme_op_settings', $sanitize_settings );
	global $ipt_theme_op_settings;
	$ipt_theme_op_settings = get_option( 'ipt_theme_op_settings', false );
}

/**
 * Returns a sanitized version of settings depending upon the default values
 *
 * This should always be used to get the settings, not get_options
 *
 * @return array Settings array
 */
function ipt_theme_op_get_settings() {
	$default_settings = ipt_theme_op_get_default_settings();
	$existing_settings = get_option( 'ipt_theme_op_settings', false );
	$sanitized_settings = ipt_theme_op_merge_arrays( $existing_settings, $default_settings, true );
	return apply_filters( 'ipt_theme_op_current_settings', $sanitized_settings );
}

/**
 * Recursively merges two arrays
 *
 * And rejects keys that is not set in the structure
 *
 * This can be directly used on $_POST and $default_settings type arrays
 * Works good with every HTML structure and data structure defined by this plugin
 *
 * @param  array   $element     The new element
 * @param  array   $structure   The element default structure
 * @param  boolean $merge_only  Whether it is a simple merge so should it check for boolean data against input[type="checkbox"] (basically for processing POST data)
 * @return array                The resulting array
 */
function ipt_theme_op_merge_arrays( $element, $structure, $merge_only = false ) {
	$fresh = array();
	foreach ( (array) $structure as $s_key => $sval ) {
		if ( is_array( $sval ) ) {
			// sda arrays in structures are always empty
			// Or it will contain just numeric keys
			// that is the array will not be associative
			// @link http://stackoverflow.com/a/173479
			if ( empty( $sval ) || array_keys( $sval ) === range( 0, count( $sval ) - 1 ) ) {
				$fresh[$s_key] = isset( $element[$s_key] ) ? $element[$s_key] : ( $merge_only ? $sval : array() );
			} else {
				$new_element = isset( $element[$s_key] ) ? $element[$s_key] : array();
				$fresh[$s_key] = ipt_theme_op_merge_arrays( $new_element, $sval, $merge_only );
			}
		} elseif ( is_bool( $sval ) ) {
				$fresh[$s_key] = ( ( isset( $element[$s_key] ) && null !== $element[$s_key] && false !== $element[$s_key] && '' !== $element[$s_key] ) ) ? true : ( ( isset( $element[$s_key] ) ? $element[$s_key] : ( $merge_only ) ? $sval : false ) ); //Check for ajax submission as well
				//var_dump($element[$s_key], $fresh[$s_key]);
		} else {
			$fresh[$s_key] = isset( $element[$s_key] ) ? $element[$s_key] : $sval;
		}
	}
	return $fresh;
}

