<?php
/**
 * Set of look and feel APIs
 *
 * Used mainly by the frontend
 *
 * @package iPanelThemes Theme Options
 * @subpackage APIs
 */
