<?php
/**
 * Set of layout APIs
 *
 * Used mainly by the frontend
 *
 * @package iPanelThemes Theme Options
 * @subpackage APIs
 */

function ipt_theme_op_layout_copyright( $echo = true ) {
	global $ipt_theme_op_settings;
	$return = wpautop( $ipt_theme_op_settings['layout']['copyright'] );
	$return = str_replace( '%Y%', current_time( 'Y', false ), $return );
	if ( $echo ) {
		echo $return;
	}
	return $return;
}
