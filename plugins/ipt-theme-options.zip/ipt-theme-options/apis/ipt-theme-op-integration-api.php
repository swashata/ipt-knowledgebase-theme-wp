<?php
/**
 * Set of integration APIs
 *
 * Used mainly by the frontend
 *
 * @package iPanelThemes Theme Options
 * @subpackage APIs
 */
