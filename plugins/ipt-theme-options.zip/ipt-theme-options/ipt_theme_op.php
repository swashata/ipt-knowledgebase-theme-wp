<?php
/*
Plugin Name: iPanelThemes Theme Options
Description: Theme Options plugin packed with every theme released and maintained by iPanelThemes
Plugin URI: https://iptlabz.com/ipanelthemes/ipt-theme-options
Author: iPanelThemes
Author URI: http://ipanelthemes.com
Version: 0.0.17
License: GPL3
Text Domain: ipt_thm
Domain Path: translations
*/

/*
    Copyright (C) 2014  iPanelThemes  ipanelthemes@gmail.com

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

include_once dirname( __FILE__ ) . '/classes/class-ipt-theme-op-loader.php';
include_once dirname( __FILE__ ) . '/apis/ipt-theme-op-general-apis.php';
include_once dirname( __FILE__ ) . '/classes/class-ipt-theme-op-shortcodes.php';
if ( is_admin() ) {
	include_once dirname( __FILE__ ) . '/lib/classes/class-ipt-theme-uif-base.php';
	include_once dirname( __FILE__ ) . '/lib/classes/class-ipt-theme-uif-admin.php';
	include_once dirname( __FILE__ ) . '/classes/class-ipt-bootstrap-walker-nav-menu-edit.php';
	include_once dirname( __FILE__ ) . '/classes/class-ipt-theme-op-admin.php';
} else {
	include_once dirname( __FILE__ ) . '/apis/ipt-theme-op-laf-api.php';
	include_once dirname( __FILE__ ) . '/apis/ipt-theme-op-layout-api.php';
	include_once dirname( __FILE__ ) . '/apis/ipt-theme-op-integration-api.php';
	include_once dirname( __FILE__ ) . '/apis/ipt-theme-op-navigation-api.php';
}

global $ipt_theme_op_info, $ipt_theme_op_settings;

$ipt_theme_op = new IPT_Theme_Op_Loader( __FILE__, 'ipt_thm', '0.0.17', 'ipt_thm', 'https://iptlabz.com/ipanelthemes/ipt-theme-options/wikis/home', 'https://iptlabz.com/ipanelthemes/ipt-theme-options/issues' );

$ipt_theme_op->load();
