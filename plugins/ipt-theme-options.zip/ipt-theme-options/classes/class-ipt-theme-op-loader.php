<?php
/**
 * IPT Theme Options Loader
 * The library of loader class
 *
 * @author Swashata <swashata4u@gmail.com>
 * @package iPanelThemes Theme Options
 * @subpackage Loader
 */

class IPT_Theme_Op_Loader {
	/**
	 * The init classes used to generate the admin menu
	 * The class should initialize and hook itself
	 *
	 * @see /classes/admin-class.php and extend from the base abstract class
	 * @staticvar array
	 */
	static $init_classes = array();

	/**
	 *
	 *
	 * @staticvar string
	 * Holds the absolute path of the main plugin file directory
	 */
	static $abs_path;

	/**
	 *
	 *
	 * @staticvar string
	 * Holds the absolute path of the main plugin file
	 */
	static $abs_file;

	/**
	 * Holds the text domain
	 * Use the string directly instead
	 * But still set this for some methods, especially the loading of the textdomain
	 */
	static $text_domain;

	/**
	 * Holds the absolute URL to the main plugin directory
	 * @var string
	 */
	static $abs_url;

	/**
	 *
	 *
	 * @staticvar string
	 * The current version of the plugin
	 */
	static $version;

	/**
	 *
	 *
	 * @staticvar string
	 * The abbreviated name of the plugin
	 * Mainly used for the enqueue style and script of the default admin.css and admin.js file
	 */
	static $abbr;


	/**
	 * Constructor function
	 *
	 * @global array $ipt_theme_op_info The information option variable
	 * @param type    $file_loc
	 * @param type    $classes
	 * @param type    $text_domain
	 * @param type    $version
	 * @param type    $abbr
	 */
	public function __construct( $file_loc, $text_domain = 'default', $version = '1.0.0', $abbr = '' ) {
		self::$abs_path = dirname( $file_loc );
		self::$abs_file = $file_loc;
		self::$text_domain = $text_domain;
		self::$version = $version;
		self::$abbr = $abbr;
		self::$abs_url = plugins_url( '/', self::$abs_file );
		self::$init_classes = array( 'IPT_Theme_Op_Admin' );
	}

	public function load() {
		//activation hook
		register_activation_hook( self::$abs_file, array( $this, 'plugin_install' ) );
		// deactivation hook
		register_deactivation_hook( self::$abs_file, array( $this, 'plugin_deactivate' ) );
		//* Load Text Domain For Translations //
		add_action( 'plugins_loaded', array( $this, 'plugin_textdomain' ) );
		// Check for version and database compatibility //
		add_action( 'after_setup_theme', array( $this, 'database_version' ) );


		//var_dump(self::$init_classes);

		//admin area
		if ( is_admin() ) {
			//admin menu items
			add_action( 'plugins_loaded', array( $this, 'init_admin_menus' ), 20 );
			add_action( 'admin_init', array( $this, 'gen_admin_menu' ), 20 );
			add_action( 'admin_print_styles', array( $this, 'admin_menu_style' ) );
			// Add the styles and scripts for global admin menus
			add_action( 'admin_print_styles', array( $this, 'admin_global_enqueue' ) );

			// Add metaboxes for fontIconPicker
			add_action( 'add_meta_boxes', array( $this, 'fip_meta' ) );
			add_action( 'save_post', array( $this, 'fip_save' ) );
		} else {
			//add frontend script + style
			add_action( 'wp_print_styles', array( $this, 'enqueue_script_style' ) );
		}

		add_action( 'init', array( $this, 'plugin_init' ) );

		// Add the options when the theme is completely loaded
		add_action( 'after_setup_theme', array( $this, 'after_setup_theme' ) );

		global $ipt_theme_op_info;
		$ipt_theme_op_info = get_option( 'ipt_theme_op_info' );

		// Save custom fields from menu
		add_action( 'wp_update_nav_menu_item', 'ipt_bootstrap_walker_nav_menu_edit_update_fields', 10, 3 );

		// Change the edit menu walker
		add_filter( 'wp_edit_nav_menu_walker', 'ipt_bootstrap_walker_nav_menu_edit_filter', 10, 2 );

		// Add the shortcodes
		$shortcodes = new IPT_Theme_Op_Shortcodes();

		//other filters + actions
		//add_action($tag, $function_to_add);
		//add_filter($tag, $function_to_add);
	}

	public function plugin_init() {
		$theme_custom_posts = apply_filters( 'ipt_theme_op_custom_posts', array() );
		$flush_rewrite_rules = false;

		$flushed = get_option( 'ipt_theme_op_flush_custom_post', array() );

		if ( ! is_array( $flushed ) ) {
			$flushed = array();
		}
		if ( ! empty( $theme_custom_posts ) ) {
			foreach ( $theme_custom_posts as $id => $args ) {
				if ( ! in_array( $id, $flushed ) ) {
					$flush_rewrite_rules = true;
					$flushed[] = $id;
				}
				register_post_type( $id, $args );
			}
		}
		if ( $flush_rewrite_rules ) {
			flush_rewrite_rules();
			update_option( 'ipt_theme_op_flush_custom_post', array_unique( $flushed ) );
		}

	}

	public function after_setup_theme() {
		// Set the global options
		global $ipt_theme_op_settings;
		$ipt_theme_op_settings = ipt_theme_op_get_settings();

		// Load the pluggable APIs
		include_once self::$abs_path . '/apis/ipt-theme-op-pluggable-apis.php';

		// Add the font stylesheet for editor
		add_editor_style( self::$abs_url . 'lib/fonts/icomoon.css' );

		// Add the tinyMCE icon picker
		if ( get_user_option('rich_editing') == 'true' ) {
			add_filter( 'mce_external_plugins', array( $this, 'tinymce_plugins' ) );
			add_filter( 'mce_buttons', array( $this, 'tinymce_buttons' ) );
		}
	}

	public function init_admin_menus() {
		self::$init_classes = apply_filters( 'ipt_theme_op_admin_menus', self::$init_classes );
		foreach ( (array) self::$init_classes as $class ) {
			if ( class_exists( $class ) ) {
				global ${'admin_menu' . $class};
				${'admin_menu' . $class} = new $class();
			}
		}
	}


	public function gen_admin_menu() {
		$admin_menus = array();
		foreach ( (array) self::$init_classes as $class ) {
			if ( class_exists( $class ) ) {
				global ${'admin_menu' . $class};
				$admin_menus[] = ${'admin_menu' . $class}->get_pagehook();
			}
		}

		foreach ( $admin_menus as $menu ) {
			add_action( 'admin_print_styles-' . $menu, array( $this, 'admin_enqueue_script_style' ) );
		}

	}

	public function admin_menu_style() {

	}

	public function admin_enqueue_script_style() {
		$ui = IPT_Theme_UIF_Admin::instance( self::$text_domain );
		$ui->enqueue( plugins_url( '/lib/', self::$abs_file ), self::$version );
		wp_enqueue_style( 'ipt_theme_op_fonts', '//fonts.googleapis.com/css?family=Roboto:100,300,400,300italic,400italic', array(), self::$version );
		wp_enqueue_style( 'ipt_theme_op_admin', plugins_url( '/static/admin/css/ipt-theme-uif-admin-theme-op.css', self::$abs_file ), array(), self::$version );
		wp_enqueue_script( 'ipt_theme_op_admin_js', plugins_url( '/static/admin/js/jquery.iPtThemeOpAdmin.js', self::$abs_file ), array( 'jquery' ), self::$version );
	}

	public function admin_global_enqueue() {
		$screen = get_current_screen();
		// Enqueue the icon fonts on all screens
		wp_enqueue_style( 'ipt-icomoon-fonts', self::$abs_url . 'lib/fonts/icomoon.css', array(), self::$version );

		// Add the nav-menus
		if ( $screen && $screen->id == 'nav-menus' ) {
			wp_enqueue_style( 'ipt-bwnme-css', self::$abs_url . 'static/admin/css/ipt-bwnme-css.css', array(), self::$version );
			wp_enqueue_style( 'ipt-theme-uif-fip', self::$abs_url . 'lib/css/jquery.fonticonpicker.min.css', array(), self::$version );
			wp_enqueue_style( 'ipt-theme-uif-fip-theme', self::$abs_url . 'lib/css/jquery.fonticonpicker.ipt.css', array(), self::$version );
			wp_enqueue_style( 'ipt-icomoon-fonts', self::$abs_url . 'lib/fonts/icomoon.css', array(), self::$version );

			wp_enqueue_script( 'ipt-theme-uif-fip-js', self::$abs_url . 'lib/js/jquery.fonticonpicker.min.js', array( 'jquery' ), self::$version );
			wp_enqueue_script( 'ipt-bwnme-js', self::$abs_url . 'static/admin/js/jquery.ipt-bwnme.js', array( 'jquery' ), self::$version );
		}

		// Add the fontIconPicker for post meta
		// We use screen base so that it can be added to all custom post types
		if ( $screen && $screen->base == 'post' ) {
			wp_enqueue_style( 'ipt-theme-uif-fip', self::$abs_url . 'lib/css/jquery.fonticonpicker.min.css', array(), self::$version );
			wp_enqueue_style( 'ipt-theme-uif-fip-theme', self::$abs_url . 'lib/css/jquery.fonticonpicker.ipt.css', array(), self::$version );

			wp_enqueue_script( 'ipt-theme-uif-fip-js', self::$abs_url . 'lib/js/jquery.fonticonpicker.min.js', array( 'jquery' ), self::$version );
			wp_enqueue_script( 'ipt-theme-uif-fip-js', self::$abs_url . 'lib/js/jquery.fonticonpicker.min.js', array( 'jquery' ), self::$version );
			wp_enqueue_script( 'ipt-theme-op-post-meta', self::$abs_url . 'static/admin/js/jquery.iPtThemeOpPostMeta.js', array( 'jquery' ), self::$version );
			wp_localize_script( 'ipt-theme-op-post-meta', 'iPtThemeOpPostMetaL10n', array(
				'picker'        => __( 'Use Icon Picker', 'ipt_thm' ),
				'picker_cancel' => __( 'Enter Manual Class', 'ipt_thm' ),
				'label_cancel'  => __( 'Pick Icon', 'ipt_thm' ),
				'label'         => __( 'Icon Class', 'ipt_thm' ),
			) );
		}
	}

	public function enqueue_script_style() {
		/**
		 * Everything here might as well be handled by the theme itself
		 * Since right now this plugin is more of a backend rather than a frontend
		 *
		 * Future plans
		 * 1. Add shortcodes
		 * 2. Add preset widget factory
		 * 3. Add author box
		 * 4. Add testimonial
		 */
	}

	public function tinymce_plugins( $plugins ) {
		$plugins['ipt_tinymce_iconpicker'] = self::$abs_url . 'static/admin/js/tinyMCE.iconpicker.js';
		return $plugins;
	}

	public function tinymce_buttons( $buttons ) {
		array_push( $buttons, 'ipt_tinymce_iconpicker' );
		return $buttons;
	}

	public function fip_meta( $post_type ) {
		$screen = get_current_screen();
		if ( $screen && $screen->base == 'post' && current_user_can( 'edit_others_posts' ) ) {
			add_meta_box( 'ipt_themeop_fip_meta', __( 'Layout Options', 'ipt_thm' ), array( $this, 'fip_meta_cb' ), $post_type, 'side', 'high' );
		}
	}

	public function fip_meta_cb( $post ) {
		// Nonce field for authentication
		wp_nonce_field( 'ipt_themeop_fip_meta', 'ipt_themeop_fip_meta_nonce' );

		// Get existing value
		$icon = get_post_meta( $post->ID, 'ipt_theme_op_single_icon', true );
		if ( ! $icon ) {
			$icon = 'none';
		}
		do_action( 'ipt_theme_op_fip_meta_cb_before', $post );
		echo '<p>';
		echo '<label for="ipt_themeop_fip_meta_picker">' . __( 'Pick Icon', 'ipt_thm' ) . '</label>&nbsp;&nbsp;';
		echo '<input type="text" id="ipt_themeop_fip_meta_picker" name="ipt_themeop_fip_meta_picker" value="' . esc_attr( $icon ) . '" class="ipt-meta-fip code" size="15" />&nbsp;';
		echo '<button class="ipt-meta-fip-toggle button-secondary" title="">' . '<i class="ipticm ipt-icomoon-close"></i>' . '</button>';
		echo '</p>';
		do_action( 'ipt_theme_op_fip_meta_cb_after', $post );
	}

	public function fip_save( $post_id ) {
		// Is nonce set?
		if ( ! isset( $_POST['ipt_themeop_fip_meta_nonce'] ) ) {
			return;
		}

		// Invalid nonce?
		if ( ! wp_verify_nonce( $_POST['ipt_themeop_fip_meta_nonce'], 'ipt_themeop_fip_meta' ) ) {
			return;
		}

		// autosave?
		if (  defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE  ) {
			return;
		}

		// User has permission?
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		// Is it set?
		if ( ! isset( $_POST['ipt_themeop_fip_meta_picker'] ) ) {
			return;
		}

		// Everything set, now save
		$icon = sanitize_text_field( stripslashes( $_POST['ipt_themeop_fip_meta_picker'] ) );
		update_post_meta( $post_id, 'ipt_theme_op_single_icon', $icon );

		do_action( 'ipt_theme_op_fip_meta_save', $post_id );
	}

	public function plugin_install( $networkwide = false ) {
		include_once self::$abs_path . '/classes/class-ipt-theme-op-install.php';

		$install = new IPT_Theme_Op_Install();
		$install->install( $networkwide );
	}

	public function plugin_deactivate() {
		flush_rewrite_rules();
	}

	public function database_version() {
		global $ipt_theme_op_info;
		$d_version = $ipt_theme_op_info['version'];
		$s_version = self::$version;

		if ( $d_version != $s_version ) {
			include_once self::$abs_path . '/classes/class-ipt-theme-op-install.php';

			$install = new IPT_Theme_Op_Install();
			$install->checkop();
			$install->checkdb();
		}
	}

	/**
	 * Load the text domain on plugin load
	 * Hooked to the plugins_loaded via the load method
	 *
	 * dirname( plugin_basename( self::$abs_file ) )
	 */
	public function plugin_textdomain() {
		load_plugin_textdomain( 'ipt_thm', false, basename( dirname( self::$abs_file ) ) . '/translations' );
	}
}
