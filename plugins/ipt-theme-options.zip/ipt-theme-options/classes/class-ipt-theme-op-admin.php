<?php
/**
 * IPT Theme Option Admin
 * The library of all the administration classes
 *
 * @author Swashata <swashata4u@gmail.com>
 * @package IPT Theme Options
 * @subpackage Admin Backend classes
 * @version 1.0.0
 */

class IPT_Theme_Op_Admin extends IPT_Theme_Op_Admin_Base {
	static $instance;

	public function __construct() {
		$this->capability = 'manage_options';
		$this->action_nonce = 'ipt_theme_op_admin_nonce';

		parent::__construct();

		$this->icon = 'paint-format';
		self::$instance = $this;
	}

	public function admin_menu() {
		$this->pagehook = add_theme_page( __( 'iPanelThemes Theme Options', 'ipt_thm' ), __( 'Theme Options', 'ipt_thm' ), $this->capability, 'ipt_theme_options', array( $this, 'index' ) );
		parent::admin_menu();
	}

	public function index() {
		$this->index_head( __( 'iPanelThemes Theme Options', 'ipt_thm' ) );
		$main_tabs = apply_filters( 'ipt_theme_op_admin_tabs', array(
			array(
				'id'            => 'ipt_laf',
				'label'         => __( '<i class="ipticm ipt-icomoon-desktop"></i> Look and Feel', 'ipt_thm' ),
				'callback'      => array( $this, 'settings_laf' ),
				'scroll'        => false,
				'classes'       => array(),
				'has_inner_tab' => false,
			),
			array(
				'id'            => 'ipt_layout',
				'label'         => __( '<i class="ipticm ipt-icomoon-columns"></i> Layout', 'ipt_thm' ),
				'callback'      => array( $this, 'settings_layout' ),
				'scroll'        => false,
				'classes'       => array(),
				'has_inner_tab' => false,
			),
			array(
				'id'            => 'ipt_integration',
				'label'         => __( '<i class="ipticm ipt-icomoon-code"></i> Integration', 'ipt_thm' ),
				'callback'      => array( $this, 'settings_integration' ),
				'scroll'        => false,
				'classes'       => array(),
				'has_inner_tab' => false,
			),
			array(
				'id'            => 'ipt_navigation',
				'label'         => __( '<i class="ipticm ipt-icomoon-menu2"></i> Navigation Menu', 'ipt_thm' ),
				'callback'      => array( $this, 'settings_navigation' ),
				'scroll'        => false,
				'classes'       => array(),
				'has_inner_tab' => false,
			),
			array(
				'id'            => 'ipt_social',
				'label'         => __( '<i class="ipticm ipt-icomoon-share"></i> Social Networking Profiles', 'ipt_thm' ),
				'callback'      => array( $this, 'settings_social' ),
				'scroll'        => false,
				'classes'       => array(),
				'has_inner_tab' => false,
			),
		) );
		$main_tabs[] = array(
			'id'            => 'ipt_imp_exp',
			'label'         => __( '<i class="ipticm ipt-icomoon-download"></i> Import/Export', 'ipt_thm' ),
			'callback'      => array( $this, 'settings_imp_exp' ),
			'scroll'        => false,
			'classes'       => array(),
			'has_inner_tab' => false,
		);
		$this->ui->tabs( $main_tabs, false, true );
		$this->index_foot();
	}

	public function save_post() {
		parent::save_post( false );
		$new_settings = array();
		if ( isset( $this->post['send_as_str'] ) && $this->post['send_as_str'] == 'true' ) {
			parse_str( $this->post[$this->post['look_into']], $new_settings );
		} else {
			$new_settings = $this->post;
		}
		@header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );

		$return = array(
			'success' => false,
			'errors' => array(),
		);

		if ( ! wp_verify_nonce( $new_settings[ $this->action_nonce ], $this->action_nonce ) ) {
			$return['errors'][] = __( 'Invalid nonce', 'ipt_thm' );
		} else {
			ipt_theme_op_set_settings( $new_settings );
			$return['success'] = true;
		}

		echo json_encode( (object) $return );
		die();
	}

	/*==========================================================================
	 * Inbuilt Settings Functions
	 *========================================================================*/
	public function settings_imp_exp() {
		?>
<h2>//TODO</h2>
		<?php
	}

	public function settings_laf() {
		global $ipt_theme_op_settings;
		$op = $ipt_theme_op_settings['laf'];
		do_action( 'ipt_theme_op_settings_laf_out_table_before' );
		$logo_meta = apply_filters( 'ipt_theme_op_logo_meta', array(
			'height' => '128px',
			'width' => '128px',
			'background_size' => '100% 100%',
		) );
		$favicon_meta = apply_filters( 'ipt_theme_op_favicon_meta', array(
			'height' => '32px',
			'width' => '32px',
			'background_size' => '100% 100%',
		) );
		?>
<table class="form-table">
	<tbody>
		<?php do_action( 'ipt_theme_op_settings_laf_in_table_before' ); ?>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'laf[logo]', __( 'Upload Logo', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->upload( 'laf[logo]', $op['logo'], '', __( 'Upload Logo', 'ipt_thm' ), __( 'Choose Image', 'ipt_thm' ), __( 'Use as site logo', 'ipt_thm' ), $logo_meta['width'], $logo_meta['height'], $logo_meta['background_size'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Upload the logo that will be used by your theme.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'laf[favicon]', __( 'Upload Favicon', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->upload( 'laf[favicon]', $op['favicon'], '', __( 'Upload Favicon', 'ipt_thm' ), __( 'Choose Image', 'ipt_thm' ), __( 'Use as site favicon', 'ipt_thm' ), $favicon_meta['width'], $favicon_meta['height'], $favicon_meta['background_size'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Upload the favicon that will be used by your theme.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'laf[fonts][body]', __( 'Choose body fonts', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->webfonts( 'laf[fonts][body]', $op['fonts']['body'], $this->get_available_webfonts() ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set body font family. Font weight is subjected to availability.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'laf[fonts][heading]', __( 'Choose heading fonts', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->webfonts( 'laf[fonts][heading]', $op['fonts']['heading'], $this->get_available_webfonts() ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Set heading font family. Font weight is subjected to availability.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<?php do_action( 'ipt_theme_op_settings_laf_in_table_after' ); ?>
	</tbody>
</table>
		<?php
		do_action( 'ipt_theme_op_settings_laf_out_table_after' );
	}

	public function settings_layout() {
		global $ipt_theme_op_settings;
		$op = $ipt_theme_op_settings['layout'];
		$settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Title', 'ipt_thm' ),
					'size' => '15',
					'type' => 'text',
				),
				1 => array(
					'label' => __( 'Icon', 'ipt_thm' ),
					'size' => '15',
					'type' => 'icon_selector',
				),
				2 => array(
					'label' => __( 'Description', 'ipt_thm' ),
					'size' => '25',
					'type' => 'textarea',
				),
				3 => array(
					'label' => __( 'Button Text', 'ipt_thm' ),
					'size' => '15',
					'type' => 'text',
				),
				4 => array(
					'label' => __( 'Button Link', 'ipt_thm' ),
					'size' => '15',
					'type' => 'text',
				),
			),
		);
		$items = array();
		$max_key = null;
		foreach ( (array) $op['features'] as $f_key => $features ) {
			$max_key = max ( $max_key, $f_key );
			$items[] = array(
				0 => array( 'layout[features][' . $f_key . '][title]', $features['title'], __( 'Title of the feature', 'ipt_thm' ) ),
				1 => array( 'layout[features][' . $f_key . '][icon]', $features['icon'] ),
				2 => array( 'layout[features][' . $f_key . '][description]', $features['description'], __( 'Description - HTML allowed', 'ipt_thm' ) ),
				3 => array( 'layout[features][' . $f_key . '][button]', $features['button'], __( 'Do not show', 'ipt_thm' ) ),
				4 => array( 'layout[features][' . $f_key . '][link]', $features['link'], __( 'Do not link', 'ipt_thm' ) ),
			);
		}
		$data = array(
			0 => array( 'layout[features][__SDAKEY__][title]', '', __( 'Title of the feature', 'ipt_thm' ) ),
			1 => array( 'layout[features][__SDAKEY__][icon]', 0xf004 ),
			2 => array( 'layout[features][__SDAKEY__][description]', '', __( 'Description - HTML allowed', 'ipt_thm' ) ),
			3 => array( 'layout[features][__SDAKEY__][button]', '', __( 'Do not show', 'ipt_thm' ) ),
			4 => array( 'layout[features][__SDAKEY__][link]', '', __( 'Do not link', 'ipt_thm' ) ),
		);
		$settings = apply_filters( 'ipt_theme_op_features_settings', $settings );
		$items = apply_filters( 'ipt_theme_op_features_items', $items );
		$max_key = apply_filters( 'ipt_theme_op_features_max_key', $max_key );
		$data = apply_filters( 'ipt_theme_op_features_data', $data );
		do_action( 'ipt_theme_op_settings_layout_out_table_before' );
		?>
<table class="form-table">
	<tbody>
		<?php do_action( 'ipt_theme_op_settings_layout_in_table_before' ); ?>
		<tr>
			<td colspan="3">
				<h3><?php _e( 'Archive', 'ipt_thm' ); ?></h3>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'layout[archive_view]', __( 'Archive View', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->select( 'layout[archive_view]', array(
					array(
						'label' => 'Excerpt',
						'value' => 'excerpt',
					),
					array(
						'label' => 'Full Content',
						'value' => 'full',
					),
				), $op['archive_view'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'Select the listing view of archive pages, including home page.', 'ipt_thm' ); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<h3><?php _e( 'Theme featured section', 'ipt_thm' ); ?></h3>
				<?php $this->ui->sda_list( $settings, $items, $data, $max_key ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'layout[copyright]', __( 'Copyright Text', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->text( 'layout[copyright]', $op['copyright'], __( 'Keep it short', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the copyright text you want to show (depends on the theme, mostly it is shown in the footer).', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<?php do_action( 'ipt_theme_op_settings_layout_in_table_after' ); ?>
	</tbody>
</table>
		<?php
		do_action( 'ipt_theme_op_settings_layout_out_table_after' );
	}

	public function settings_integration() {
		global $ipt_theme_op_settings;
		$op = $ipt_theme_op_settings['integration'];
		do_action( 'ipt_theme_op_settings_integration_out_table_before' );
		?>
<table class="form-table">
	<tbody>
		<?php do_action( 'ipt_theme_op_settings_integration_in_table_before' ); ?>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'integration[header]', __( 'Header Code', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->textarea( 'integration[header]', $op['header'], __( 'Enter RAW HTML code', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter RAW HTML code you would like to print to the header.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'integration[footer]', __( 'Footer Code', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->textarea( 'integration[footer]', $op['footer'], __( 'Enter RAW HTML code', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter RAW HTML code you would like to print to the footer.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<?php do_action( 'ipt_theme_op_settings_integration_in_table_after' ); ?>
	</tbody>
</table>
		<?php
		do_action( 'ipt_theme_op_settings_integration_out_table_after' );
	}

	public function settings_navigation() {
		global $ipt_theme_op_settings;
		$op = $ipt_theme_op_settings['navigation'];
		$logo_meta = apply_filters( 'ipt_theme_op_nav_logo_meta', array(
			'height' => '32px',
			'width' => '32px',
			'background_size' => '100% 100%',
		) );
		$settings_logged_in_links = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Title', 'ipt_thm' ),
					'size' => '45',
					'type' => 'text',
				),
				1 => array(
					'label' => __( 'Icon', 'ipt_thm' ),
					'size' => '15',
					'type' => 'icon_selector',
				),
				2 => array(
					'label' => __( 'Link', 'ipt_thm' ),
					'size' => '25',
					'type' => 'text',
				),
			),
		);
		$items_logged_in_links = array();
		$max_key_logged_in_links = null;
		foreach ( (array) $op['logged_in_links'] as $s_key => $logged_in_link ) {
			$max_key_logged_in_links = max ( $max_key_logged_in_links, $s_key );
			$items_logged_in_links[] = array(
				0 => array( 'navigation[logged_in_links][' . $s_key . '][title]', $logged_in_link['title'], __( 'Menu Title', 'ipt_thm' ) ),
				1 => array( 'navigation[logged_in_links][' . $s_key . '][icon]', $logged_in_link['icon'] ),
				2 => array( 'navigation[logged_in_links][' . $s_key . '][link]', $logged_in_link['link'], __( 'Menu Link', 'ipt_thm' ) ),
			);
		}
		$data_logged_in_links = array(
			0 => array( 'navigation[logged_in_links][__SDAKEY__][title]', '', __( 'Menu Title', 'ipt_thm' ) ),
			1 => array( 'navigation[logged_in_links][__SDAKEY__][icon]', 'none' ),
			2 => array( 'navigation[logged_in_links][__SDAKEY__][link]', '', __( 'Menu Link', 'ipt_thm' ) ),
		);
		$settings_logged_in_links = apply_filters( 'ipt_theme_op_logged_in_links_settings', $settings_logged_in_links );
		$items_logged_in_links = apply_filters( 'ipt_theme_op_logged_in_links_items', $items_logged_in_links );
		$max_key_logged_in_links = apply_filters( 'ipt_theme_op_logged_in_links_max_key', $max_key_logged_in_links );
		$data_logged_in_links = apply_filters( 'ipt_theme_op_logged_in_links_data', $data_logged_in_links );

		$settings_logged_out_links = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Title', 'ipt_thm' ),
					'size' => '45',
					'type' => 'text',
				),
				1 => array(
					'label' => __( 'Icon', 'ipt_thm' ),
					'size' => '15',
					'type' => 'icon_selector',
				),
				2 => array(
					'label' => __( 'Link', 'ipt_thm' ),
					'size' => '25',
					'type' => 'text',
				),
			),
		);
		$items_logged_out_links = array();
		$max_key_logged_out_links = null;
		foreach ( (array) $op['logged_out_links'] as $s_key => $logged_out_link ) {
			$max_key_logged_out_links = max ( $max_key_logged_out_links, $s_key );
			$items_logged_out_links[] = array(
				0 => array( 'navigation[logged_out_links][' . $s_key . '][title]', $logged_out_link['title'], __( 'Menu Title', 'ipt_thm' ) ),
				1 => array( 'navigation[logged_out_links][' . $s_key . '][icon]', $logged_out_link['icon'] ),
				2 => array( 'navigation[logged_out_links][' . $s_key . '][link]', $logged_out_link['link'], __( 'Menu Link', 'ipt_thm' ) ),
			);
		}
		$data_logged_out_links = array(
			0 => array( 'navigation[logged_out_links][__SDAKEY__][title]', '', __( 'Menu Title', 'ipt_thm' ) ),
			1 => array( 'navigation[logged_out_links][__SDAKEY__][icon]', 'none' ),
			2 => array( 'navigation[logged_out_links][__SDAKEY__][link]', '', __( 'Menu Link', 'ipt_thm' ) ),
		);
		$settings_logged_out_links = apply_filters( 'ipt_theme_op_logged_out_links_settings', $settings_logged_out_links );
		$items_logged_out_links = apply_filters( 'ipt_theme_op_logged_out_links_items', $items_logged_out_links );
		$max_key_logged_out_links = apply_filters( 'ipt_theme_op_logged_out_links_max_key', $max_key_logged_out_links );
		$data_logged_out_links = apply_filters( 'ipt_theme_op_logged_out_links_data', $data_logged_out_links );
		do_action( 'ipt_theme_op_settings_navigation_out_table_before' );
		?>
<table class="form-table">
	<tbody>
		<?php do_action( 'ipt_theme_op_settings_navigation_in_table_before' ); ?>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'navigation[image]', __( 'Brand Logo', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->upload( 'navigation[image]', $op['image'], '', __( 'Upload Logo', 'ipt_thm' ), __( 'Choose Image', 'ipt_thm' ), __( 'Use as site logo', 'ipt_thm' ), $logo_meta['width'], $logo_meta['height'], $logo_meta['background_size'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Upload the logo that will be used on the navbar by your theme.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'navigation[brand]', __( 'Brand Name', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->text( 'navigation[brand]', $op['brand'], __( 'Keep it short', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter the brand text you want to show in the navbar.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'navigation[show_login]', __( 'Show dynamic login and logout button', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( 'navigation[show_login]', __( 'Yes', 'ipt_thm' ), __( 'No', 'ipt_thm' ), $op['show_login'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'Select yes if you would like to show a dynamic login/logout button. It auto integrates with bbPress and buddyPress to show profile links.', 'ipt_thm' ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'navigation[search_bar]', __( 'Show a search bar', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->toggle( 'navigation[search_bar]', __( 'Yes', 'ipt_thm' ), __( 'No', 'ipt_thm' ), $op['search_bar'] ); ?>
			</td>
			<td>
				<?php $this->ui->help( 'Select yes if you would like to show a search bar.', 'ipt_thm' ); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<?php $this->ui->help( __( 'Define additional set of dropdown links shown to the users who are logged in.', 'ipt_thm' ), __( 'Logged In links', 'ipt_thm' ) ) ?>
				<h3><?php _e( 'Logged in dropdown links', 'ipt_thm' ); ?></h3>
				<?php $this->ui->sda_list( $settings_logged_in_links, $items_logged_in_links, $data_logged_in_links, $max_key_logged_in_links ); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<?php $this->ui->help( __( 'Define additional set of dropdown links shown to the users who are not logged in.', 'ipt_thm' ), __( 'Logged Out links', 'ipt_thm' ) ) ?>
				<h3><?php _e( 'Logged out dropdown links', 'ipt_thm' ); ?></h3>
				<?php $this->ui->sda_list( $settings_logged_out_links, $items_logged_out_links, $data_logged_out_links, $max_key_logged_out_links ); ?>
			</td>
		</tr>
		<?php do_action( 'ipt_theme_op_settings_navigation_in_table_after' ); ?>
	</tbody>
</table>
		<?php
		do_action( 'ipt_theme_op_settings_navigation_out_table_after' );
	}

	public function settings_social() {
		global $ipt_theme_op_settings;
		$op = $ipt_theme_op_settings['social'];
		$settings = array(
			'columns' => array(
				0 => array(
					'label' => __( 'Title', 'ipt_thm' ),
					'size' => '25',
					'type' => 'text',
				),
				1 => array(
					'label' => __( 'Icon', 'ipt_thm' ),
					'size' => '15',
					'type' => 'icon_selector',
				),
				2 => array(
					'label' => __( 'Button Link', 'ipt_thm' ),
					'size' => '25',
					'type' => 'text',
				),
				3 => array(
					'label' => __( 'Button Color', 'ipt_thm' ),
					'size' => '15',
					'type' => 'colorpicker',
				),
			),
		);
		$items = array();
		$max_key = null;
		foreach ( (array) $op['profiles'] as $s_key => $profile ) {
			$max_key = max ( $max_key, $s_key );
			$items[] = array(
				0 => array( 'social[profiles][' . $s_key . '][title]', $profile['title'], __( 'Title of the site', 'ipt_thm' ) ),
				1 => array( 'social[profiles][' . $s_key . '][icon]', $profile['icon'] ),
				2 => array( 'social[profiles][' . $s_key . '][link]', $profile['link'], __( 'Profile Link', 'ipt_thm' ) ),
				3 => array( 'social[profiles][' . $s_key . '][color]', $profile['color'], __( 'Color code', 'ipt_thm' ) ),
			);
		}
		$data = array(
			0 => array( 'social[profiles][__SDAKEY__][title]', '', __( 'Title of the site', 'ipt_thm' ) ),
			1 => array( 'social[profiles][__SDAKEY__][icon]', 'none' ),
			2 => array( 'social[profiles][__SDAKEY__][link]', '', __( 'Profile Link', 'ipt_thm' ) ),
			3 => array( 'social[profiles][__SDAKEY__][color]', '', __( 'Color code', 'ipt_thm' ) ),
		);
		$settings = apply_filters( 'ipt_theme_op_social_settings', $settings );
		$items = apply_filters( 'ipt_theme_op_social_items', $items );
		$max_key = apply_filters( 'ipt_theme_op_social_max_key', $max_key );
		$data = apply_filters( 'ipt_theme_op_social_data', $data );
		do_action( 'ipt_theme_op_settings_social_out_table_before' );
		?>
<table class="form-table">
	<tbody>
		<?php do_action( 'ipt_theme_op_settings_social_in_table_before' ); ?>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'social[facebook_like]', __( 'Facebook Like Code', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->textarea( 'social[facebook_like]', $op['facebook_like'], __( 'Enter RAW HTML code', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter RAW HTML code you would like to print to for the Facebook Like Widget.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<th>
				<?php $this->ui->generate_label( 'social[twitter_widget]', __( 'Twitter Widget Code', 'ipt_thm' ) ); ?>
			</th>
			<td>
				<?php $this->ui->textarea( 'social[twitter_widget]', $op['twitter_widget'], __( 'Enter RAW HTML code', 'ipt_thm' ), 'fit', 'normal', array( 'code' ) ); ?>
			</td>
			<td>
				<?php $this->ui->help( __( 'Enter RAW HTML code you would like to print to for the Twitter Widget.', 'ipt_thm' ) ); ?>
			</td>
		</tr>
		<tr>
			<td colspan="3">
				<h3><?php _e( 'Social Networking Profiles', 'ipt_thm' ); ?></h3>
				<?php $this->ui->sda_list( $settings, $items, $data, $max_key ); ?>
			</td>
		</tr>
		<?php do_action( 'ipt_theme_op_settings_social_in_table_after' ); ?>
	</tbody>
</table>
		<?php
		do_action( 'ipt_theme_op_settings_social_out_table_after' );
	}

	/*==========================================================================
	 * Internal methods
	 *========================================================================*/
	public function get_available_webfonts() {
		$web_fonts = array(
			'oswald' => array(
				'label' => "'Oswald', 'Arial Narrow', sans-serif",
				'include' => 'Oswald',
			),
			'roboto' => array(
				'label' => "'Roboto', Tahoma, Geneva, sans-serif",
				'include' => 'Roboto',
			),
			'quando' => array(
				'label' => "Quando, Georgia, serif",
				'include' => 'Quando',
			),
			'signika_negative' => array(
				'label' => "'Signika Negative', Verdana, sans-serif",
				'include' => 'Signika+Negative',
			),
			'lobster' => array(
				'label' => "'Lobster', Georgia, Times, serif",
				'include' => 'Lobster',
			),
			'cabin' => array(
				'label' => "'Cabin', Helvetica, Arial, sans-serif",
				'include' => 'Cabin',
			),
			'allerta' => array(
				'label' => "'Allerta', Helvetica, Arial, sans-serif",
				'include' => 'Allerta',
			),
			'crimson' => array(
				'label' => "'Crimson Text', Georgia, Times, serif",
				'include' => 'Crimson+Text',
			),
			'arvo' => array(
				'label' => "'Arvo', Georgia, Times, serif",
				'include' => 'Arvo',
			),
			'pt_sans' => array(
				'label' => "'PT Sans', Helvetica, Arial, sans-serif",
				'include' => 'PT+Sans',
			),
			'dancing_script' => array(
				'label' => "'Dancing Script', Georgia, Times, serif",
				'include' => 'Dancing+Script',
			),
			'josefin_sans' => array(
				'label' => "'Josefin Sans', Helvetica, Arial, sans-serif",
				'include' => 'Josefin+Sans',
			),
			'allan' => array(
				'label' => "'Allan', Helvetica, Arial, sans-serif",
				'include' => 'Allan',
			),
			'cardo' => array(
				'label' => "'Cardo', Georgia, Times, serif",
				'include' => 'Cardo',
			),
			'molengo' => array(
				'label' => "'Molengo', Georgia, Times, serif",
				'include' => 'Molengo',
			),
			'lekton' => array(
				'label' => "'Lekton', Helvetica, Arial, sans-serif",
				'include' => 'Lekton',
			),
			'droid_sans' => array(
				'label' => "'Droid Sans', Helvetica, Arial, sans-serif",
				'include' => 'Droid+Sans',
			),
			'droid_serif' => array(
				'label' => "'Droid Serif', Georgia, Times, serif",
				'include' => 'Droid+Serif',
			),
			'corben' => array(
				'label' => "'Corben', Georgia, Times, serif",
				'include' => 'Corben',
			),
			'nobile' => array(
				'label' => "'Nobile', Helvetica, Arial, sans-serif",
				'include' => 'Nobile',
			),
			'ubuntu' => array(
				'label' => "'Ubuntu', Helvetica, Arial, sans-serif",
				'include' => 'Ubuntu',
			),
			'vollkorn' => array(
				'label' => "'Vollkorn', Georgia, Times, serif",
				'include' => 'Vollkorn',
			),
			'bree_serif' => array(
				'label' => "'Bree Serif', Georgia, serif",
				'include' => 'Bree+Serif',
			),
			'open_sans' => array(
				'label' => "'Open Sans', Verdana, Helvetica, sans-serif",
				'include' => 'Open+Sans',
			),
			'bevan' => array(
				'label' => "'Bevan', Georgia, serif",
				'include' => 'Bevan',
			),
			'pontano_sans' => array(
				'label' => "'Pontano Sans', Verdana, Helvetica, sans-serif",
				'include' => 'Pontano+Sans',
			),
			'abril_fatface' => array(
				'label' => "'Abril Fatface', Georgia, serif",
				'include' => 'Abril+Fatface',
			),
			'average' => array(
				'label' => "'Average', Garamond, Georgia, serif",
				'include' => 'Average',
			),
			'lato' => array(
				'label' => "'Lato', sans-serif",
				'include' => 'Lato',
			),
			'Roboto_Condensed' => array(
				'label' => "'Roboto Condensed', 'Arial', sans-serif",
				'include' => 'Roboto+Condensed',
			),
			'Nato_Sans' => array(
				'label' => "'Nato Sans', Arial, sans-serif",
				'include' => 'Nato+Sans',
			),
			'Titillium Web' => array(
				'label' => "'Titillium Web', Arial, serif",
				'include' => 'Titillium+Web',
			),
			'Oxygen' => array(
				'label' => "'Oxygen', Arial, serif",
				'include' => 'Oxygen',
			),
			'Crafty_Girls' => array(
				'label' => "'Crafty Girls', cursive",
				'include' => 'Crafty+Girls',
			),
			'Dancing_Script' => array(
				'label' => "'Dancing Script', Arial, serif",
				'include' => 'Dancing+Script',
			),
			'Cuprum' => array(
				'label' => "'Cuprum', Arial, serif",
				'include' => 'Cuprum',
			),
			'Josefin_Sans' => array(
				'label' => "'Josefin Sans', sans-serif",
				'include' => 'Josefin+Sans',
			),
			'Philosopher' => array(
				'label' => "'Philosopher', sans-serif",
				'include' => 'Philosopher',
			),
			'Libre_Baskerville' => array(
				'label' => "'Libre Baskerville', serif",
				'include' => 'Libre+Baskerville',
			),
			'Merriweather_Sans' => array(
				'label' => "'Merriweather Sans', sans-serif",
				'include' => 'Merriweather+Sans',
			),
			'Asap' => array(
				'label' => "'Asap', sans-serif",
				'include' => 'Asap',
			),
			'Rokkitt' => array(
				'label' => "'Rokkitt', serif",
				'include' => 'Rokkitt',
			),
			'Gilda_Display' => array(
				'label' => "'Gilda Display', serif",
				'include' => 'Gilda+Display',
			),
			'Pinyon_Script' => array(
				'label' => "'Pinyon Script', cursive",
				'include' => 'Pinyon+Script',
			),
			'Tinos' => array(
				'label' => "'Tinos', serif",
				'include' => 'Tinos',
			),
			'Cabin_Condensed' => array(
				'label' => "'Cabin Condensed', sans-serif",
				'include' => 'Cabin+Condensed',
			),
			'Montserrat_Alternates' => array(
				'label' => "'Montserrat Alternates', sans-serif",
				'include' => 'Montserrat+Alternates',
			),
			'PT_Sans_Caption' => array(
				'label' => "'PT Sans Caption', sans-serif",
				'include' => 'PT+Sans+Caption',
			),
			'Economica' => array(
				'label' => "'Economica', sans-serif",
				'include' => 'Economica',
			),
			'Playfair_Display_SC' => array(
				'label' => "'Playfair Display SC', serif",
				'include' => 'Playfair+Display+SC',
			),
			'Hammersmith_One' => array(
				'label' => "'Hammersmith One', sans-serif",
				'include' => 'Hammersmith+One',
			),
			'Exo' => array(
				'label' => "'Exo', sans-serif",
				'include' => 'Exo',
			),
			'Poiret_One' => array(
				'label' => "'Poiret One', cursive",
				'include' => 'Poiret+One',
			),
			'Oleo_Script' => array(
				'label' => "'Oleo Script', cursive",
				'include' => 'Oleo+Script',
			),
			'Satisfy' => array(
				'label' => "'Satisfy', cursive",
				'include' => 'Satisfy',
			),
			'Chivo' => array(
				'label' => "'Chivo', sans-serif",
				'include' => 'Chivo',
			),
			'Marvel' => array(
				'label' => "'Marvel', sans-serif",
				'include' => 'Marvel',
			),
			'Quattrocento' => array(
				'label' => "'Quattrocento', serif",
				'include' => 'Quattrocento',
			),
			'Metrophobic' => array(
				'label' => "'Metrophobic', sans-serif",
				'include' => 'Metrophobic',
			),
			'Judson' => array(
				'label' => "'Judson', serif",
				'include' => 'Judson',
			),
			'Arbutus_Slab' => array(
				'label' => "'Arbutus Slab', serif",
				'include' => 'Arbutus+Slab',
			),
			'Electrolize' => array(
				'label' => "'Electrolize', sans-serif",
				'include' => 'Electrolize',
			),
			'Varela' => array(
				'label' => "'Varela', sans-serif",
				'include' => 'Varela',
			),
			'Julius_Sans_One' => array(
				'label' => "'Julius Sans One', sans-serif",
				'include' => 'Julius+Sans+One',
			),
			'ABeeZee' => array(
				'label' => "'ABeeZee', sans-serif",
				'include' => 'ABeeZee',
			),
			'Kite_One' => array(
				'label' => "'Kite One', sans-serif",
				'include' => 'Kite+One',
			),
			'Noto_Sans' => array(
				'label' => "'Noto Sans', sans-serif",
				'include' => 'Noto+Sans',
			),
			'Cinzel' => array(
				'label' => "'Cinzel', serif",
				'include' => 'Cinzel',
			),
			'Trykker' => array(
				'label' => "'Trykker', serif",
				'include' => 'Trykker',
			),
			'Jacques_Francois' => array(
				'label' => "'Jacques Francois', serif",
				'include' => 'Jacques+Francois',
			),
			'Domine' => array(
				'label' => "'Domine', serif",
				'include' => 'Domine',
			),
			'Comfortaa' => array(
				'label' => "'Comfortaa', cursive",
				'include' => 'Comfortaa',
			),
			'Salsa' => array(
				'label' => "'Salsa', cursive",
				'include' => 'Salsa',
			),
			'Nova_Square' => array(
				'label' => "'Nova Square', cursive",
				'include' => 'Nova+Square',
			),
			'Iceland' => array(
				'label' => "'Iceland', cursive",
				'include' => 'Iceland',
			),
			'Lancelot' => array(
				'label' => "'Lancelot', cursive",
				'include' => 'Lancelot',
			),
			'Supermercado_One' => array(
				'label' => "'Supermercado One', cursive",
				'include' => 'Supermercado+One',
			),
			'Averia_Libre' => array(
				'label' => "'Averia Libre', cursive",
				'include' => 'Averia+Libre',
			),
			'Croissant_One' => array(
				'label' => "'Croissant One', cursive",
				'include' => 'Croissant+One',
			),
			'Averia_Gruesa_Libre' => array(
				'label' => "'Averia Gruesa Libre', cursive",
				'include' => 'Averia+Gruesa+Libre',
			),
			'Overlock' => array(
				'label' => "'Overlock', cursive",
				'include' => 'Overlock',
			),
			'Lobster_Two' => array(
				'label' => "'Lobster Two', cursive",
				'include' => 'Lobster+Two',
			),
			'Bevan' => array(
				'label' => "'Bevan', cursive",
				'include' => 'Bevan',
			),
			'Pompiere' => array(
				'label' => "'Pompiere', cursive",
				'include' => 'Pompiere',
			),
			'Kelly_Slab' => array(
				'label' => "'Kelly Slab', cursive",
				'include' => 'Kelly+Slab',
			),
			'Carter_One' => array(
				'label' => "'Carter One', cursive",
				'include' => 'Carter+One',
			),
			'Inconsolata' => array(
				'label' => "'Inconsolata'",
				'include' => 'Inconsolata',
			),
			'Ubuntu_Mono' => array(
				'label' => "'Ubuntu Mono'",
				'include' => 'Ubuntu+Mono',
			),
			'Droid_Sans_Mono' => array(
				'label' => "'Droid Sans Mono'",
				'include' => 'Droid+Sans+Mono',
			),
			'Source_Code_Pro' => array(
				'label' => "'Source Code Pro'",
				'include' => 'Source+Code+Pro',
			),
			'Nova_Mono' => array(
				'label' => "'Nova Mono'",
				'include' => 'Nova+Mono',
			),
			'PT_Mono' => array(
				'label' => "'PT Mono'",
				'include' => 'PT+Mono',
			),
			'Cutive_Mono' => array(
				'label' => "'Cutive Mono'",
				'include' => 'Cutive+Mono',
			),
			'Crete_Round' => array(
				'label' => "'Crete Round', serif",
				'include' => 'Crete Round',
			),
			'EB_Garamond' => array(
				'label' => "'EB Garamond', serif",
				'include' => 'EB+Garamond',
			),
			'Cardo' => array(
				'label' => "'Cardo', serif",
				'include' => 'Cardo',
			),
			'Fanwood_Text' => array(
				'label' => "'Fanwood Text', serif",
				'include' => 'Fanwood+Text',
			),
			'Trocchi' => array(
				'label' => "'Trocchi', serif",
				'include' => 'Trocchi',
			),
			'Fauna_One' => array(
				'label' => "'Fauna One', serif",
				'include' => 'Fauna+One',
			),
			'Prata' => array(
				'label' => "'Prata', serif",
				'include' => 'Prata',
			),
		);

		return apply_filters( 'ipt_theme_op_available_webfonts', $web_fonts );
	}

}

/**
 * The base admin class
 *
 * @abstract
 */
abstract class IPT_Theme_Op_Admin_Base {
	/**
	 * Duplicates the $_POST content and properly process it
	 * Holds the typecasted (converted int and floats properly and escaped html) value after the constructor has been called
	 *
	 * @var array
	 */
	public $post = array();

	/**
	 * Holds the hook of this page
	 *
	 * @var string Pagehook
	 * Should be set during the construction
	 */
	public $pagehook;

	/**
	 * The nonce for admin-post.php
	 * Should be set the by extending class
	 *
	 * @var string
	 */
	public $action_nonce;

	/**
	 * The class of the admin page icon
	 * Should be set by the extending class
	 *
	 * @var string
	 */
	public $icon;

	/**
	 * This gets passed directly to current_user_can
	 * Used for security and should be set by the extending class
	 *
	 * @var string
	 */
	public $capability;

	/**
	 * Holds the URL of the static directories
	 * Just the /static/admin/ URL and sub directories under it
	 * access it like $url['js'], ['images'], ['css'], ['root'] etc
	 *
	 * @var array
	 */
	public $url = array();

	/**
	 * Holds the URL of the common directories
	 *
	 * @var array
	 */
	public $common_url = array();

	/**
	 * Set this to true if you are going to use the WordPress Metabox appearance
	 * This will enqueue all the scripts and will also set the screenlayout option
	 *
	 * @var bool False by default
	 */
	public $is_metabox = false;

	/**
	 * Default number of columns on metabox
	 *
	 * @var int
	 */
	public $metabox_col = 2;

	/**
	 * Holds the post result message string
	 * Each entry is an associative array with the following options
	 *
	 * $key : The code of the post_result value =>
	 *
	 *      'type' => 'update' : The class of the message div update | error
	 *
	 *      'msg' => '' : The message to be displayed
	 *
	 * @var array
	 */
	public $post_result = array();

	/**
	 * The action value to be used for admin-post.php
	 * This is generated automatically by appending _post_action to the action_nonce variable
	 *
	 * @var string
	 */
	public $admin_post_action;

	/**
	 * Whether or not to print form on the admin wrap page
	 * Mainly for manually printing the form
	 *
	 * @var bool
	 */
	public $print_form;

	/**
	 * The USER INTERFACE Object
	 *
	 * @var IPT_Plugin_UIF_Admin
	 */
	public $ui;

	/**
	 * Whether or not the submit should be done via ajax
	 *
	 * It can be initialized with index_head
	 *
	 * @var boolean
	 */
	public $ajax_submit = false;

	/**
	 * The constructor function
	 * 1. Properly copies the $_POST to $this->post on POST request
	 * 2. Calls the admin_menu() function
	 * You should have parent::__construct() for all these to happen
	 *
	 * @param boolean $gets_hooked Should be true if you wish to actually put this inside an admin menu. False otherwise
	 * It basically hooks into admin_menu and admin_post_ if true
	 */
	public function __construct( $gets_hooked = true ) {
		if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
			//$this->post = $_POST;

			//we do not need to check on magic quotes
			//as wordpress always adds magic quotes
			//@link http://codex.wordpress.org/Function_Reference/stripslashes_deep
			$this->post = array_map( 'stripslashes_deep', $_POST );

			//convert html to special characters
			//array_walk_recursive ($this->post, array($this, 'htmlspecialchar_ify'));
		}

		$this->ui = IPT_Theme_UIF_Admin::instance( 'ipt_thm' );

		$plugin = IPT_Theme_Op_Loader::$abs_file;

		$this->url = array(
			'root' => plugins_url( '/static/admin/', $plugin ),
			'js' => plugins_url( '/static/admin/js/', $plugin ),
			'images' => plugins_url( '/static/admin/images/', $plugin ),
			'css' => plugins_url( '/static/admin/css/', $plugin ),
		);

		$this->common_url = array(
			'root' => plugins_url( '/static/common/', $plugin ),
			'js' => plugins_url( '/static/common/js/', $plugin ),
			'images' => plugins_url( '/static/common/images/', $plugin ),
			'css' => plugins_url( '/static/common/css/', $plugin ),
		);

		$this->post_result = array(
			1 => array(
				'type' => 'update',
				'msg' => __( 'Successfully saved the options.', 'ipt_thm' ),
			),
			2 => array(
				'type' => 'error',
				'msg' => __( 'Either you have not changed anything or some error has occured. Please contact the developer.', 'ipt_thm' ),
			),
			3 => array(
				'type' => 'okay',
				'msg' => __( 'The Master Reset was successful.', 'ipt_thm' ),
			),
		);

		$this->admin_post_action = $this->action_nonce . '_post_action';

		if ( $gets_hooked ) {
			//register admin_menu hook
			add_action( 'admin_menu', array( &$this, 'admin_menu' ) );

			//register admin-post.php hook
			add_action( 'admin_post_' . $this->admin_post_action, array( &$this, 'save_post' ) );
		}
	}

	/*==========================================================================
	 * SYSTEM METHODS
	 *========================================================================*/


	/**
	 * Hook to the admin menu
	 * Should be overriden and also the hook should be saved in the $this->pagehook
	 * In the end, the parent::admin_menu() should be called for load to hooked properly
	 */
	public function admin_menu() {
		add_action( 'load-' . $this->pagehook, array( &$this, 'on_load_page' ) );
		//$this->pagehook = add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function);
		//do the above or similar in the overriden callback function
	}

	/**
	 * Use this to generate the admin page
	 * always call parent::index() so the save post is called
	 * also call $this->index_foot() after the generation of page (the last line of this function)
	 * to give some compatibility (mainly with the metaboxes)
	 *
	 * @access public
	 */
	abstract public function index();

	protected function index_head( $title = '', $print_form = true, $ajax_submit = true, $ui_state = 'back' ) {
		$this->print_form = $print_form;
		$this->ajax_submit = $ajax_submit;
		$ui_class = 'ipt_uif';

		switch ( $ui_state ) {
		case 'back' :
			$ui_class = 'ipt_uif';
			break;
		case 'front' :
			$ui_class = 'ipt_uif_front';
			break;
		default :
		case 'none' :
			$ui_class = 'ipt_uif_common';
		}
		$theme_meta = apply_filters( 'ipt_theme_op_active_theme_meta', array(
			'documentation' => array(
				'icon' => 'ipt-icomoon-library',
				'link' => 'http://ipanelthemes.com/kb/',
				'text' => __( 'Documentation', 'ipt_thm' ),
			),
			'support' => array(
				'icon' => 'ipt-icomoon-support',
				'link' => 'http://ipanelthemes.com/kb/support',
				'text' => __( 'Support', 'ipt_thm' ),
			),
			'home'    => array(
				'icon' => 'ipt-icomoon-home2',
				'link' => 'http://ipanelthemes.com/',
				'text' => __( 'iPanelThemes', 'ipt_thm' ),
			),
			'themes'    => array(
				'icon' => 'ipt-icomoon-droplet',
				'link' => 'http://ipanelthemes.com/themes/',
				'text' => __( 'Themes', 'ipt_thm' ),
			),
			'plugins'    => array(
				'icon' => 'ipt-icomoon-powercord',
				'link' => 'http://ipanelthemes.com/plugins/',
				'text' => __( 'Plugins', 'ipt_thm' ),
			),
		) );
?>
<style type="text/css">
	<?php echo '#' . $this->pagehook; ?>-widgets .meta-box-sortables {
		margin: 0 8px;
	}
</style>
<div class="wrap ipt_uif_common <?php echo $ui_class; ?>" id="<?php echo $this->pagehook; ?>_widgets">
	<div class="icon32">
		<span class="ipt-icomoon-<?php echo $this->icon; ?>"></span>
	</div>
	<h2><?php echo $title; ?></h2>
	<?php $this->ui->clear(); ?>
	<?php
		if ( isset( $_GET['post_result'] ) ) {
			$msg = $this->post_result[(int) $_GET['post_result']];
			if ( !empty( $msg ) ) {
				if ( $msg['type'] == 'update' || $msg['type'] == 'updated' ) {
					$this->print_update( $msg['msg'] );
				} else if ( $msg['type'] == 'okay' ) {
						$this->print_p_okay( $msg['msg'] );
					} else {
					$this->print_error( $msg['msg'] );
				}
			}
		}
?>
	<?php if ( $this->print_form ) : ?>
	<form method="post" action="admin-post.php" id="<?php echo $this->pagehook; ?>_form_primary" data-ajax-submit="<?php echo (int) $ajax_submit; ?>">
		<input type="hidden" name="action" value="<?php echo $this->admin_post_action; ?>" />
		<?php wp_nonce_field( $this->action_nonce, $this->action_nonce ); ?>
		<?php if ( $this->is_metabox ) : ?>
		<?php wp_nonce_field( 'closedpostboxes', 'closedpostboxesnonce', false ); ?>
		<?php wp_nonce_field( 'meta-box-order', 'meta-box-order-nonce', false ); ?>
		<?php endif; ?>
	<?php endif; ?>
	<?php do_action( $this->pagehook . '_page_before', $this ); ?>
	<div id="ipt_theme_op_wrap">
		<div id="ipt_theme_op_head">
			<div class="ipt_uif_box">
				<div class="ipt_uif_column_small ipt_uif_left_col">
					<img src="<?php echo apply_filters( 'ipt_theme_op_active_theme_logo', $this->common_url['images'] . 'logos/512x512.png' ); ?>" alt="iPanelThemes" id="ipt_theme_op_logo" /><br />
					<p><?php printf( __( 'Framework version: %1$s', 'ipt_thm' ), IPT_Theme_Op_Loader::$version ); ?></p>
				</div>
				<div class="ipt_uif_column_large ipt_uif_left_col">
					<h4>
						<?php _e( 'Welcome to iPanelThemes Options Page', 'ipt_thm' ); ?>
					</h4>
					<ul class="ul-square">
						<li><strong><?php _e( 'Active Theme:', 'ipt_thm' ); ?></strong> <?php echo apply_filters( 'ipt_theme_op_active_theme_name', 'N/A' ); ?></li>
						<li><strong><?php _e( 'Theme Version:', 'ipt_thm' ); ?></strong> <?php echo apply_filters( 'ipt_theme_op_active_theme_version', 'N/A' ); ?></li>
					</ul>
				</div>
				<div class="clear"></div>
				<ul id="ipt_theme_meta">
					<?php foreach ( $theme_meta as $id => $meta ) : ?>
					<li id="<?php echo esc_attr( $id ); ?>">
						<a href="<?php echo $meta['link']; ?>">
							<i class="ipticm <?php echo esc_attr( $meta['icon'] ); ?>"></i> <?php echo $meta['text']; ?>
						</a>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<div id="ipt_theme_op_main_tabs">
			<div class="ipt_uif_shadow lifted_corner">
		<?php
	}

	/**
	 * Include this to the end of index function so that metaboxes work
	 */
	protected function index_foot( $submit = true, $save = 'Save Changes', $reset = 'Reset' ) {
		$buttons = array(
			array( $save, '', 'large', 'primary', 'normal', array(), 'submit' ),
			array( $reset, '', 'small', 'secondary', 'normal', array(), 'reset' ),
		);
?>			</div>
		</div>
	</div>
	<?php if ( $this->print_form ) : ?>
		<?php if ( true == $submit ) : ?>
		<div class="clear"></div>
		<?php $this->ui->buttons( $buttons ); ?>
		<?php endif; ?>
		<?php if ( $this->ajax_submit ) : ?>
		<?php $this->ui->ajax_loader( true, 'ipt_theme_op_settings_ajax_loader', array(
			'wait'  => __( 'Please Wait', 'ipt_thm' ),
			'done'  => __( 'Success', 'ipt_thm' ),
			'error' => __( 'HTTP Error', 'ipt_thm' ),
		) ); ?>
		<?php endif; ?>
	</form>
	<?php endif; ?>
	<div class="clear"></div>
	<?php do_action( $this->pagehook . '_page_after', $this ); ?>
</div>
<?php if ( $this->is_metabox ) : ?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready( function($) {
	if(postboxes) {
		// close postboxes that should be closed
		$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
		// postboxes setup
		postboxes.add_postbox_toggles('<?php echo $this->pagehook; ?>');
	}
});
//]]>
</script>
<?php endif; ?>
		<?php
	}

	/**
	 * Override to manage the save_post
	 * This should be written by all the classes extending this
	 *
	 *
	 * * General Template
	 *
	 * //process here your on $_POST validation and / or option saving
	 *
	 * //lets redirect the post request into get request (you may add additional params at the url, if you need to show save results
	 * wp_redirect(add_query_arg(array(), $_POST['_wp_http_referer']));
	 *
	 *
	 */
	public function save_post( $check_referer = true ) {
		//user permission check
		if ( !current_user_can( $this->capability ) )
			wp_die( __( 'Cheatin&#8217; uh?' ) );
		//check nonce
		if ( $check_referer ) {
			if ( !wp_verify_nonce( $_POST[$this->action_nonce], $this->action_nonce ) )
				wp_die( __( 'Cheatin&#8217; uh?' ) );
		}

		//process here your on $_POST validation and / or option saving

		//lets redirect the post request into get request (you may add additional params at the url, if you need to show save results
		//wp_redirect(add_query_arg(array(), $_POST['_wp_http_referer']));
		//The above should be done by the extending after calling parent::save_post and processing post
	}

	/**
	 * Hook to the load plugin page
	 * This should be overriden
	 * Also call parent::on_load_page() for screenoptions
	 *
	 * @uses add_meta_box
	 */
	public function on_load_page() {

	}

	/**
	 * Get the pagehook of this class
	 *
	 * @return string
	 */
	public function get_pagehook() {
		return $this->pagehook;
	}

	/**
	 * Prints the metaboxes of a custom context
	 * Should atleast pass the $context, others are optional
	 *
	 * The screen defaults to the $this->pagehook so make sure it is set before using
	 * This should be the return value given by add_admin_menu or similar function
	 *
	 * The function automatically checks the screen layout columns and prints the normal/side columns accordingly
	 * If screen layout column is 1 then even if you pass with context side, it will be hidden
	 * Also if screen layout is 1 and you pass with context normal, it will get full width
	 *
	 * @param string  $context           The context of the metaboxes. Depending on this HTML ids are generated. Valid options normal | side
	 * @param string  $container_classes (Optional) The HTML class attribute of the container
	 * @param string  $container_style   (Optional) The RAW inline CSS style of the container
	 */
	public function print_metabox_containers( $context = 'normal', $container_classes = '', $container_style = '' ) {
		global $screen_layout_columns;
		$style = 'width: 50%;';

		//check to see if only one column has to be shown

		if ( isset( $screen_layout_columns ) && $screen_layout_columns == 1 ) {
			//normal?
			if ( 'normal' == $context ) {
				$style = 'width: 100%;';
			} else if ( 'side' == $context ) {
					$style = 'display: none;';
				}
		}

		//override for the special debug area (1 column)
		if ( 'debug' == $context ) {
			$style = 'width: 100%;';
			$container_classes .= ' debug-metabox';
		}
?>
<div class="postbox-container <?php echo $container_classes; ?>" style="<?php echo $style . $container_style; ?>" id="<?php echo ( 'normal' == $context )? 'postbox-container-1' : 'postbox-container-2'; ?>">
	<?php do_meta_boxes( $this->pagehook, $context, '' ); ?>
</div>
		<?php
	}


	/*==========================================================================
	 * INTERNAL METHODS
	 *========================================================================*/

	/**
	 * Prints error msg in WP style
	 *
	 * @param string  $msg
	 */
	protected function print_error( $msg = '', $echo = true ) {
		return $this->ui->msg_error( $msg, $echo );
	}

	protected function print_update( $msg = '', $echo = true ) {
		return $this->ui->msg_update( $msg, $echo );
	}

	protected function print_p_error( $msg = '', $echo = true ) {
		return $this->ui->msg_error( $msg, $echo );
	}

	protected function print_p_update( $msg = '', $echo = true ) {
		return $this->ui->msg_update( $msg, $echo );
	}

	protected function print_p_okay( $msg = '', $echo = true ) {
		return $this->ui->msg_okay( $msg, $echo );
	}

	/**
	 * stripslashes gpc
	 * Strips Slashes added by magic quotes gpc thingy
	 *
	 * @access protected
	 * @param string  $value
	 */
	protected function stripslashes_gpc( &$value ) {
		$value = stripslashes( $value );
	}

	protected function htmlspecialchar_ify( &$value ) {
		$value = htmlspecialchars( $value );
	}

	/*==========================================================================
	 * SHORTCUT HTML METHODS
	 *========================================================================*/


	/**
	 * Shortens a string to a specified character length.
	 * Also removes incomplete last word, if any
	 *
	 * @param string  $text The main string
	 * @param string  $char Character length
	 * @param string  $cont Continue character(…)
	 * @return string
	 */
	public function shorten_string( $text, $char, $cont = '…' ) {
		return $this->ui->shorten_string( $text, $char, $cont );
	}

	/**
	 * Get the first image from a string
	 *
	 * @param string  $html
	 * @return mixed string|bool The src value on success or boolean false if no src found
	 */
	public function get_first_image( $html ) {
		return $this->ui->get_first_image( $html );
	}

	/**
	 * Wrap a RAW JS inside <script> tag
	 *
	 * @param String  $string The JS
	 * @return String The wrapped JS to be used under HTMl document
	 */
	public function js_wrap( $string ) {
		return $this->ui->js_wrap( $string );
	}

	/**
	 * Wrap a RAW CSS inside <style> tag
	 *
	 * @param String  $string The CSS
	 * @return String The wrapped CSS to be used under HTMl document
	 */
	public function css_wrap( $string ) {
		return $this->ui->css_wrap( $string );
	}

	public function print_datetimepicker( $name, $value, $dateonly = false ) {
		if ( $dateonly ) {
			$this->ui->datepicker( $name, $value );
		} else {
			$this->ui->datetimepicker( $name, $value );
		}
	}

	/**
	 * Prints options of a selectbox
	 *
	 * @param array   $ops Should pass either an array of string ('label1', 'label2') or associative array like array('val' => 'val1', 'label' => 'label1'),...
	 * @param string  $key The key in the haystack, if matched a selected="selected" will be printed
	 */
	public function print_select_op( $ops, $key, $inner = false ) {
		$items = $this->ui->convert_old_items( $ops, $inner );
		$this->ui->select( '', $items, $key, false, false, false, false );
	}

	/**
	 * Prints a set of checkboxes for a single HTML name
	 *
	 * @param string  $name    The HTML name of the checkboxes
	 * @param array   $items   The associative array of items array('val' => 'value', 'label' => 'label'),...
	 * @param array   $checked The array of checked items. It matches with the 'val' of the haystack array
	 * @param string  $sep     (Optional) The seperator, HTML non-breaking-space (&nbsp;) by default. Can be <br /> or anything
	 */
	public function print_checkboxes( $name, $items, $checked, $sep = '&nbsp;&nbsp;' ) {
		$items = $this->ui->convert_old_items( $items );
		$this->ui->checkboxes( $name, $items, $checked, false, false, $sep );
	}

	/**
	 * Prints a set of radioboxes for a single HTML name
	 *
	 * @param string  $name    The HTML name of the checkboxes
	 * @param array   $items   The associative array of items array('val' => 'value', 'label' => 'label'),...
	 * @param string  $checked The value of checked radiobox. It matches with the val of the haystack
	 * @param string  $sep     (Optional) The seperator, two HTML non-breaking-space (&nbsp;) by default. Can be <br /> or anything
	 */
	public function print_radioboxes( $name, $items, $checked, $sep = '&nbsp;&nbsp;' ) {
		$items = $this->ui->convert_old_items( $items );
		$this->ui->radios( $name, $items, $checked, false, false, $sep );
	}

	/**
	 * Print a single checkbox
	 * Useful for printing a single checkbox like for enable/disable type
	 *
	 * @param string  $name  The HTML name
	 * @param string  $value The value attribute
	 * @param mixed   (string|bool) $checked Can be true or can be equal to the $value for adding checked attribute. Anything else and it will not be added.
	 */
	public function print_checkbox( $name, $value, $checked ) {
		if ( $value === $checked || true === $checked ) {
			$checked = true;
		}
		$this->ui->toggle( $name, '', $value, $checked );
	}

	/**
	 * Prints a input[type="text"]
	 * All attributes are escaped except the value
	 *
	 * @param string  $name  The HTML name attribute
	 * @param string  $value The value of the textbox
	 * @param string  $class (Optional) The css class defaults to regular-text
	 */
	public function print_input_text( $name, $value, $class = 'regular-text' ) {
		$this->ui->text( $name, $value, '', $class );
	}

	/**
	 * Prints a <textarea> with custom attributes
	 * All attributes are escaped except the value
	 *
	 * @param string  $name  The HTML name attribute
	 * @param string  $value The value of the textbox
	 * @param string  $class (Optional) The css class defaults to regular-text
	 * @param int     $rows  (Optional) The number of rows in the rows attribute
	 * @param int     $cols  (Optional) The number of columns in the cols attribute
	 */
	public function print_textarea( $name, $value, $class = 'regular-text', $rows = 3, $cols = 20 ) {
		$this->ui->textarea( $name, $value, '', $class );
	}


	/**
	 * Displays a jQuery UI Slider to the page
	 *
	 * @param string  $name  The HTML name of the input box
	 * @param int     $value The initial/saved value of the input box
	 * @param int     $max   The maximum of the range
	 * @param int     $min   The minimum of the range
	 * @param int     $step  The step value
	 */
	public function print_ui_slider( $name, $value, $max = 100, $min = 0, $step = 1 ) {
		$this->ui->slider( $name, $value, $min, $max, $step );
	}

	/**
	 * Prints a ColorPicker
	 *
	 * @param string  $name  The HTML name of the input box
	 * @param string  $value The HEX color code
	 */
	public function print_cpicker( $name, $value ) {
		$this->ui->colorpicker( $name, $value );
	}

	/**
	 * Prints a input box with an attached upload button
	 *
	 * @param string  $name  The HTML name of the input box
	 * @param string  $value The value of the input box
	 */
	public function print_uploadbutton( $name, $value ) {
		$this->ui->upload( $name, $value );
	}

	/*==========================================================================
	 * Useful APIs
	 *========================================================================*/

		/**
	 * Recursively checks for the structure and copy value from the element
	 *
	 * @param array   $element
	 * @param array   $structure
	 * @return mixed
	 */
	public function merge_elements( $element, $structure, $merge_only = false ) {
		$fresh = array();
		foreach ( (array) $structure as $s_key => $sval ) {
			if ( is_array( $sval ) ) {
				//sda arrays in structures are always empty
				if ( empty( $sval ) ) {
					$fresh[$s_key] = isset( $element[$s_key] ) ? $element[$s_key] : array();
				} else {
					$new_element = isset( $element[$s_key] ) ? $element[$s_key] : array();
					$fresh[$s_key] = $this->merge_elements( $new_element, $sval );
				}
			} elseif ( is_bool( $sval ) ) {
					$fresh[$s_key] = ( isset( $element[$s_key] ) && null !== $element[$s_key] && false !== $element[$s_key] && '' !== $element[$s_key] ) ? true : ( $merge_only ? $sval : false ); //Check for ajax submission as well
					//var_dump($element[$s_key], $fresh[$s_key]);
			} else {
				$fresh[$s_key] = isset( $element[$s_key] ) ? $element[$s_key] : $sval;
			}
		}

		return $fresh;
	}

}
