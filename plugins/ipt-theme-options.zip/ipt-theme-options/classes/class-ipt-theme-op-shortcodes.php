<?php
/**
 * IPT Theme Option Shortcodes
 * Some shortcodes that comes with this plugin
 *
 * @author Swashata <swashata4u@gmail.com>
 * @package IPT Theme Options
 * @subpackage Shortcodes
 * @version 1.0.0
 */

class IPT_Theme_Op_Shortcodes {
	static $feature_box_id = 0;

	public function __construct() {
		add_shortcode( 'ipt_feature_box', array( $this, 'feature_box' ) );
	}

	/**
	 * Feature box shortcode
	 *
	 * This just prints the HTML
	 * It is up to the theme to style it
	 * @param  array  $atts    Shortcode attributes
	 * @param  string $content Internal content
	 * @return string          Shortcode output
	 */
	public function feature_box( $atts, $content = null ) {
		$a = shortcode_atts( array(
			'icon' => '',
			'title' => '',
			'subtitle' => '',
			'animation' => '',
			'thumbnail' => '',
			'description' => '',
		), $atts );
		$popover_id = 'ipt-thm-fb-pop-' . self::$feature_box_id++;
		ob_start();
		?>
<div class="ipt-thm-feature-box media ipt-popover"<?php if ( $a['animation'] != '' ) echo ' data-animated="' . esc_attr( $a['animation'] ) . '"'; ?> title="<?php echo esc_attr( $a['title'] ); ?>" data-popt="<?php echo $popover_id; ?>" data-pop-placement="top auto">
	<div class="ipt-thm-feature-box-body media-body">
		<hr class="ipt-thm-feature-divider divider-top" />
		<?php if ( $a['icon'] != '' && $a['icon'] != 'none' ) : ?>
		<div class="pull-left ipt-thm-feature-box-icon">
			<i class="ipticm <?php echo esc_attr( $a['icon'] ); ?>"></i>
		</div>
		<?php endif; ?>
		<?php if ( $a['title'] != '' ) : ?>
		<h4 class="media-heading ipt-thm-feature-box-heading">
			<?php echo $a['title']; ?>
		</h4>
		<?php if ( $a['subtitle'] != '' ) : ?>
		<p class="text-muted ipt-thm-feature-box-subtitle"><em><?php echo $a['subtitle']; ?></em></p>
		<?php endif; ?>
		<div class="clearfix"></div>
		<hr class="ipt-thm-feature-divider" />
		<?php endif; ?>
		<?php if ( $a['thumbnail'] != '' ) : ?>
		<div class="ipt-thm-feature-box-thumbnail">
			<img src="<?php echo esc_attr( $a['thumbnail'] ); ?>" class="img-responsive" alt="<?php echo esc_attr( $a['title'] ); ?>" />
		</div>
		<?php endif; ?>
		<?php if ( $a['description'] != '' ) : ?>
		<div class="ipt-thm-feature-box-description">
			<p class="text-justify"><?php echo $a['description']; ?></p>
		</div>
		<?php endif; ?>
	</div>
	<div id="<?php echo $popover_id; ?>" class="hidden">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>
		<?php
		return ob_get_clean();
	}
}
