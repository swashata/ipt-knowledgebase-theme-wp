<?php
/**
 * IPT Theme Options Install
 * The library of all the installation class
 *
 * @author Swashata <swashata4u@gmail.com>
 * @package iPanelThemes Theme Options
 * @subpackage Installation
 */

class IPT_Theme_Op_Install {

	/**
	 * Database prefix
	 * Mainly used for MS compatibility
	 *
	 * @var string
	 */
	public $prefix;

	public function __construct() {
		global $wpdb;

		$this->prefix = $wpdb->prefix;
	}

	/**
	 * install
	 * Do the things
	 */
	public function install( $networkwide = false ) {
		$this->checkversions();
		$this->checkdb();
		$this->checkop();
		$this->set_capability();
	}

	/**
	 * Restores the WP Options to the defaults
	 * Deletes the default options set and calls checkop
	 */
	public function restore_op() {
		delete_option( 'ipt_theme_op_info' );
		delete_option( 'ipt_theme_op_settings' );

		$this->checkop();
	}

	/**
	 * Restores the database
	 * Deletes the current tables and freshly installs the new one
	 *
	 * @global wpdb $wpdb
	 */
	public function restore_db() {
		global $wpdb;

		$this->checkdb();
	}

	/**
	 * Checks whether PHP version 5 or greater is installed or not
	 * Also checks whether WordPress version is greater than or equal to the required
	 *
	 * If fails then it automatically deactivates the plugin
	 * and gives error
	 *
	 * @return void
	 */
	private function checkversions() {
		if ( version_compare( PHP_VERSION, '5.0.0', '<' ) ) {
			deactivate_plugins( plugin_basename( IPT_Theme_Op_Loader::$abs_file ) );
			wp_die( __( 'The plugin requires PHP version greater than or equal to 5.x.x', 'ipt_thm' ) );
			return;
		}

		if ( version_compare( get_bloginfo( 'version' ), '3.5', '<' ) ) {
			deactivate_plugins( plugin_basename( IPT_Theme_Op_Loader::$abs_file ) );
			wp_die( __( 'The plugin requires WordPress version greater than or equal to 3.5', 'ipt_thm' ) );
			return;
		}
	}

	/**
	 * creates the table and options
	 *
	 * @access public
	 * @global string $charset_collate
	 */
	public function checkdb() {
		/**
		 * Include the necessary files
		 * Also the global options
		 */
		if ( file_exists( ABSPATH . 'wp-admin/includes/upgrade.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		} else {
			require_once ABSPATH . 'wp-admin/upgrade-functions.php';
		}
		global $charset_collate;


		$prefix = $this->prefix;
		$sqls = array();

		if ( ! empty( $sqls ) ) {
			foreach ( $sqls as $sql ) {
				dbDelta ( $sql );
			}
		}
	}

	/**
	 * Creates the options
	 */
	public function checkop() {
		$prefix = $this->prefix;
		$ipt_theme_op_info = array(
			'version' => IPT_Theme_Op_Loader::$version,
		);

		$ipt_theme_op_settings = array(
			'laf'         => array(
				'logo' => get_stylesheet_directory_uri() . '/images/logo.png',
				'favicon' => '',
				'fonts' => apply_filters( 'ipt_theme_op_default_fonts', array(
					'body' => array(
						'family' => "Roboto, 'sans-serif",
						'weight' => '300',
					),
					'heading' => array(
						'family' => "Roboto, 'sans-serif",
						'weight' => '400',
					),
				) ),
			),
			'layout'      => array(
				'archive_view' => 'excerpt',
				'copyright' => __( '&copy; <a href="http://ipanelthemes.com">iPanelThemes.com</a> - %Y% | All Rights Reserved', 'ipt_thm' ),
				'features' => array(
					// SDA
					// title
					// icon
					// description
					// button
					// link
				),
			),
			'integration' => array(
				'header' => '',
				'footer' => '',
			),
			'navigation' => array(
				'show_login' => false,
				'logged_in_links' => array(), // SDA -> title, icon, link
				'logged_out_links' => array(), // SDA -> title, icon, link
				'search_bar' => false,
				'brand' => 'iPt',
				'image' => '',
			),
			'social' => array(
				'facebook_like' => '',
				'twitter_widget' => '',
				'profiles' => array(
					// SDA -> title, icon, link, color
					// Default sets
					// Facebook
					array(
						'title' => __( 'Facebook', 'ipt_thm' ),
						'icon' => 0xe028,
						'link' => 'https://www.facebook.com/iPanelThemes',
						'color' => '#3B5998',
					),
					// Twitter
					array(
						'title' => __( 'Twitter', 'ipt_thm' ),
						'icon' => 0xe02b,
						'link' => 'https://twitter.com/iPanelThemes',
						'color' => '#00A0D1',
					),
					// Google Plus
					array(
						'title' => __( 'Google Plus', 'ipt_thm' ),
						'icon' => 0xe025,
						'link' => 'https://plus.google.com/+iPanelThemes',
						'color' => '#C63D2D',
					),
					// YouTube
					array(
						'title' => __( 'YouTube', 'ipt_thm' ),
						'icon' => 0xf166,
						'link' => 'http://www.youtube.com/user/iPanelThemesTutorial/',
						'color' => '#C4302B',
					),
				),
			),
			/**
			 * TODO
			 * 1. Slider
			 */
		);

		if ( ! get_option( 'ipt_theme_op_info' ) ) {
			// Fresh installation
			add_option( 'ipt_theme_op_settings', $ipt_theme_op_settings );
			add_option( 'ipt_theme_op_info', $ipt_theme_op_info );
			add_option( 'ipt_theme_op_settings_default', $ipt_theme_op_settings );
		} else {
			// Update
			$old_op = get_option( 'ipt_theme_op_info' );

			switch ( $old_op['version'] ) {
			default :
				break;
			case '1.0.0' :
				//nothing needed
				break;
			}
			// Set the default option
			update_option( 'ipt_theme_op_settings_default', $ipt_theme_op_settings );
			// Merge the settings
			$ipt_theme_op_settings = ipt_theme_op_merge_arrays( get_option( 'ipt_theme_op_settings' ), ipt_theme_op_get_default_settings(), true );
			update_option( 'ipt_theme_op_settings', $ipt_theme_op_settings );

			// finally update the info option with the newer version
			update_option( 'ipt_theme_op_info', $ipt_theme_op_info );
		}

		// Repopulate global variables
		global $ipt_theme_op_info, $ipt_theme_op_settings;
		$ipt_theme_op_info = get_option( 'ipt_theme_op_info' );
		$ipt_theme_op_settings = ipt_theme_op_get_settings();
	}

	/**
	 * Create and set custom capabilities
	 *
	 * @global WP_Roles $wp_roles
	 */
	private function set_capability() {
		global $wp_roles;

		// add capability to admin
		// $wp_roles->add_cap( 'administrator', 'manage_feedback' );
		// $wp_roles->add_cap( 'administrator', 'view_feedback' );
	}
}
