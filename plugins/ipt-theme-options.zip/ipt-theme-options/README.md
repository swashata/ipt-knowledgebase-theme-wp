# iPanelThemes Theme Options Plugin
---
This theme framework is meant to be shipped with *premium themes* created and managed by iPanelThemes.com.

The source code is released under GPLV3. Please check for available hooks and filters.

## Table of Contents

* [Setup Guide](https://iptlabz.com/ipanelthemes/ipt-theme-options/wikis/setup-guide) - Basic Integration guide for this plugin.
* [Available Hooks](https://iptlabz.com/ipanelthemes/ipt-theme-options/wikis/plugin-hooks) - Check what hooks this plugin has to offer.
* [Available Filters](https://iptlabz.com/ipanelthemes/ipt-theme-options/wikis/plugin-filters) - Check what filters this plugin has to offer.

More will be added as we keep on developing this plugin.
